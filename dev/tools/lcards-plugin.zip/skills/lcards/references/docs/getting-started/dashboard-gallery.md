# Dashboard Gallery

Complete dashboards, not single cards: each one is a whole view built from LCARdS cards on a [Layout View](../cards/layout-view/), recorded in Home Assistant while its entities change (lights switch, levels move, alerts sound). Copy one, swap in your own entities, and build from there.

To use one:

1. Create a dashboard (**Settings > Dashboards > Add dashboard**), open it, then **Edit dashboard > Raw configuration editor**.
2. Paste the YAML and save.
3. Replace the `lcards_test_*` helpers and the sample temperature sensor with your own entities.
4. Paste your version into [Check Your Config](config-checker) before you save it.

They look best with an [HA-LCARS](https://github.com/th3jesta/ha-lcars) theme, and need no other custom cards.

## Bridge

An LCARS frame (header and footer elbows, a sidebar of buttons) around a status grid, two sliders, a toggle and a history chart.

<video class="doc-video" src="/gallery/bridge.webm" poster="/gallery/bridge.webp" title="Bridge dashboard: sidebar buttons, a status grid, power and shields sliders, a lights button and a temperature chart" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Bridge: an LCARS frame (header and footer elbows, a sidebar of buttons) around a
# main panel with a status grid, controls and a chart. Uses lcards_test_* helpers
# and a temperature sensor; swap in your own entities. Best with an HA-LCARS theme.
title: Bridge
views:
  - title: Bridge
    path: bridge
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 170px 1fr 1fr 1fr
      grid-template-rows: 64px 54px 54px 54px 54px 54px 1fr 64px
      grid-template-areas: |
        "header  header  header  header"
        "nav1    status  status  status"
        "nav2    status  status  status"
        "nav3    status  status  status"
        "nav4    power   shields lights"
        "nav5    power   shields lights"
        "filler  chart   chart   chart"
        "footer  footer  footer  footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          segment:
            bar_width: 170
            bar_height: 22
        text:
          title:
            content: BRIDGE OPERATIONS
            position: bottom-right
            font_size: 24
            color: var(--lcards-orange)
        view_layout:
          grid-area: header
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_toggle
        text:
          name:
            content: RED ALERT
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav1
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_lights
        text:
          name:
            content: LIGHTS
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav2
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_doors
        text:
          name:
            content: DOORS
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav3
      - type: custom:lcards-button
        preset: filled
        entity: input_select.lcards_test_mode
        text:
          name:
            content: MODE
        tap_action:
          action: more-info
        view_layout:
          grid-area: nav4
      - type: custom:lcards-button
        preset: filled
        entity: input_number.lcards_test_shields
        text:
          name:
            content: SHIELDS
        tap_action:
          action: more-info
        view_layout:
          grid-area: nav5
      - type: custom:lcards-button
        preset: panel-dark
        view_layout:
          grid-area: filler
      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SYSTEM, STATUS, LEVEL]
            header: true
          - [WARP CORE, "{{ 'ONLINE' if states('input_number.lcards_test_power') | float > 0 else 'OFFLINE' }}", "{{ states('input_number.lcards_test_power') | int }} %"]
          - [SHIELDS, "{{ 'RAISED' if states('input_number.lcards_test_shields') | float > 50 else 'LOW' }}", "{{ states('input_number.lcards_test_shields') | int }} %"]
          - [CABIN TEMP, NOMINAL, "{{ states('input_number.lcards_test_temperature') }} °C"]
        grid:
          grid-template-columns: 1fr 1fr 1fr
          gap: 4px
        style:
          font_size: 18px
        columns:
          - style:
              align: left
              color: var(--lcars-orange)
        view_layout:
          grid-area: status
      - type: custom:lcards-slider
        entity: input_number.lcards_test_power
        preset: pills-basic
        view_layout:
          grid-area: power
      - type: custom:lcards-slider
        entity: input_number.lcards_test_shields
        preset: gauge-basic
        view_layout:
          grid-area: shields
      - type: custom:lcards-button
        preset: lozenge
        entity: input_boolean.lcards_test_lights
        icon: mdi:lightbulb-group
        text:
          label:
            content: MAIN LIGHTS
            show: true
        tap_action:
          action: toggle
        view_layout:
          grid-area: lights
      - type: custom:lcards-chart
        sources:
          - entity: sensor.desk_sensor_temperature
            name: Deck temperature
        view_layout:
          grid-area: chart
      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          segment:
            bar_width: 170
            bar_height: 22
        view_layout:
          grid-area: footer
```
:::

## Engineering

A [Master Systems Display](../cards/msd/) of the built-in NCC-1701-A blueprint in a Picard-era frame. Shield arcs around the ship change colour with shield strength, and three controls are joined to the ship's own bridge, warp core and shuttle bay markers by routed lines. Square sidebar buttons, a tick band, a systems table and Picard sliders surround it.

<video class="doc-video" src="/gallery/engineering.webm" poster="/gallery/engineering.webp" title="Engineering dashboard: a ship blueprint inside shield arcs, with three square control buttons joined to it by lines, a column of square sidebar buttons, a tick band, a systems table, two Picard sliders and a data cascade" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Engineering: a Master Systems Display of the built-in NCC-1701-A blueprint inside a
# Picard-era frame. Shield arcs around the ship change colour with shield strength
# (the shield_* naming MSD Studio's Suggest Shield Bubble uses); controls are joined
# to the ship's own markers by routed lines. Square sidebar buttons, a tick band, a
# systems table and Picard sliders around it. Uses lcards_test_* helpers.
title: Engineering
views:
  - title: Engineering
    path: engineering
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 200px minmax(0, 1fr) 280px
      grid-template-rows: 80px minmax(0, 1fr) 44px 180px 80px
      grid-template-areas: |
        "header header header"
        "side   msd    right"
        "side   band   right"
        "side   lower  right"
        "footer footer footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 200
              bar_height: 24
              color: var(--lcards-gray-medium)
            inner_segment:
              bar_width: 52
              bar_height: 8
              color: var(--lcards-orange-medium)
        text:
          title:
            content: ENGINEERING · MAIN SYSTEMS
            position: bottom-right
            font_size: 26
            color: var(--lcards-orange)
        view_layout:
          grid-area: header

      # Sidebar: a stack of square buttons over a filler block.
      - type: custom:lcards-layout-card
        layout:
          grid-gap: 6px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: repeat(5, 56px) minmax(0, 1fr)
        cards:
          - type: custom:lcards-button
            preset: filled
            entity: input_boolean.lcards_test_toggle
            text:
              name:
                content: WARP CORE
            tap_action:
              action: toggle
          - type: custom:lcards-button
            preset: filled
            entity: input_boolean.lcards_test_lights
            text:
              name:
                content: MAIN LIGHTS
            tap_action:
              action: toggle
          - type: custom:lcards-button
            preset: filled
            entity: input_boolean.lcards_test_doors
            text:
              name:
                content: DOORS
            tap_action:
              action: toggle
          - type: custom:lcards-button
            preset: filled
            text:
              name:
                content: SENSORS
          - type: custom:lcards-button
            preset: filled
            text:
              name:
                content: LIFE SUPPORT
          - type: custom:lcards-button
            preset: panel-dark
        view_layout:
          grid-area: side

      # The ship, framed by a thin line.
      - type: custom:lcards-elbow
        elbow:
          type: frame
          segment:
            color: var(--lcards-gray-medium-dark)
          frame:
            bar_width: 3
            bar_height: 3
            outer_curve: 18
        view_layout:
          grid-area: msd
      - type: custom:lcards-msd-card
        msd:
          base_svg:
            source: builtin:ncc-1701-a-blue
          view_box: [180, 270, 1600, 720]
          overlays:
            - id: shield_fore
              type: shape
              kind: polyline
              entity: input_number.lcards_test_shields
              corner_style: miter
              points: [[1526, 431], [1553, 450], [1577, 470], [1598, 491], [1616, 512], [1631, 534], [1643, 556], [1651, 579], [1656, 602], [1658, 625], [1656, 648], [1651, 671], [1643, 694], [1631, 716], [1616, 738], [1598, 759], [1577, 780], [1553, 800], [1526, 819]]
              style:
                width: 6
                line_cap: round
                color:
                  default: "var(--lcards-blue-light)"
                  below:50: "var(--lcards-orange)"
                  below:20: "var(--lcars-alert-red, #cc0000)"
            - id: shield_starboard
              type: shape
              kind: polyline
              entity: input_number.lcards_test_shields
              corner_style: miter
              points: [[1374, 892], [1334, 905], [1292, 916], [1249, 926], [1204, 935], [1158, 942], [1111, 948], [1064, 952], [1016, 954], [968, 955], [920, 954], [872, 952], [825, 948], [778, 942], [732, 935], [687, 926], [644, 916], [602, 905], [562, 892]]
              style:
                width: 6
                line_cap: round
                color:
                  default: "var(--lcards-blue-light)"
                  below:50: "var(--lcards-orange)"
                  below:20: "var(--lcars-alert-red, #cc0000)"
            - id: shield_aft
              type: shape
              kind: polyline
              entity: input_number.lcards_test_shields
              corner_style: miter
              points: [[410, 819], [383, 800], [359, 780], [338, 759], [320, 738], [305, 716], [293, 694], [285, 671], [280, 648], [278, 625], [280, 602], [285, 579], [293, 556], [305, 534], [320, 512], [338, 491], [359, 470], [383, 450], [410, 431]]
              style:
                width: 6
                line_cap: round
                color:
                  default: "var(--lcards-blue-light)"
                  below:50: "var(--lcards-orange)"
                  below:20: "var(--lcars-alert-red, #cc0000)"
            - id: shield_port
              type: shape
              kind: polyline
              entity: input_number.lcards_test_shields
              corner_style: miter
              points: [[562, 358], [602, 345], [644, 334], [687, 324], [732, 315], [778, 308], [825, 302], [872, 298], [920, 296], [968, 295], [1016, 296], [1064, 298], [1111, 302], [1158, 308], [1204, 315], [1249, 324], [1292, 334], [1334, 345], [1374, 358]]
              style:
                width: 6
                line_cap: round
                color:
                  default: "var(--lcards-blue-light)"
                  below:50: "var(--lcards-orange)"
                  below:20: "var(--lcars-alert-red, #cc0000)"
            - id: bridge-ctl
              type: control
              attachment: top-left
              position: [190, 278]
              size: [340, 96]
              card:
                type: custom:lcards-button
                preset: filled
                entity: input_boolean.lcards_test_lights
                text:
                  name:
                    content: BRIDGE
                    font_size: 30
                tap_action:
                  action: toggle
            - id: core-ctl
              type: control
              attachment: top-left
              position: [190, 886]
              size: [340, 96]
              card:
                type: custom:lcards-button
                preset: filled
                entity: input_boolean.lcards_test_toggle
                text:
                  name:
                    content: WARP CORE
                    font_size: 30
                tap_action:
                  action: toggle
            - id: shuttle-ctl
              type: control
              attachment: top-left
              position: [1430, 886]
              size: [340, 96]
              card:
                type: custom:lcards-button
                preset: filled
                text:
                  name:
                    content: SHUTTLE BAY
                    font_size: 30
            - id: bridge-line
              type: line
              anchor: bridge-ctl
              attach_to: br
              route: auto
              corner_style: round
              style:
                color: var(--lcards-gray-medium-light)
                width: 3
            - id: core-line
              type: line
              anchor: core-ctl
              attach_to: wc
              route: auto
              corner_style: round
              style:
                color: var(--lcards-gray-medium-light)
                width: 3
            - id: shuttle-line
              type: line
              anchor: shuttle-ctl
              attach_to: sb
              route: auto
              corner_style: round
              style:
                color: var(--lcards-gray-medium-light)
                width: 3
        view_layout:
          grid-area: msd
          margin: 10px

      # A band of ticks (a pill slider) under the display.
      - type: custom:lcards-slider
        entity: input_number.lcards_test_power
        preset: pills-basic
        view_layout:
          grid-area: band

      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SYSTEM, STATUS, LEVEL]
            header: true
          - [WARP CORE, "{{ 'ONLINE' if is_state('input_boolean.lcards_test_toggle', 'on') else 'STANDBY' }}", "{{ states('input_number.lcards_test_power') | int }} %"]
          - [SHIELDS, "{{ 'RAISED' if states('input_number.lcards_test_shields') | int > 0 else 'DOWN' }}", "{{ states('input_number.lcards_test_shields') | int }} %"]
          - [MODE, input_select.lcards_test_mode, ""]
        grid:
          grid-template-columns: 2fr 1fr 1fr
          grid-template-rows: repeat(4, min-content)
          gap: 6px
        style:
          font_size: 20px
          color: var(--lcards-blue-light)
        columns:
          - style:
              align: left
              color: var(--lcards-orange)
          - style:
              align: right
          - style:
              align: right
        view_layout:
          grid-area: lower

      # Right: power and shields on Picard sliders, over a data cascade.
      - type: custom:lcards-layout-card
        layout:
          grid-gap: 6px
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr)
          grid-template-rows: minmax(0, 1.4fr) minmax(0, 1fr)
          grid-template-areas: |
            "power shields"
            "data  data"
        cards:
          - type: custom:lcards-slider
            entity: input_number.lcards_test_power
            preset: picard-gauge-vertical
            component: picard
            view_layout: { grid-area: power }
          - type: custom:lcards-slider
            entity: input_number.lcards_test_shields
            preset: picard-gauge-vertical
            component: picard
            view_layout: { grid-area: shields }
          - type: custom:lcards-data-grid
            data_mode: decorative
            format: digit
            refresh_interval: 2000
            refresh_cells: 0.2
            grid:
              grid-template-rows: repeat(6, auto)
              grid-template-columns: repeat(4, 1fr)
              gap: 0px
            style:
              font_size: 18px
              color: var(--lcards-gray-medium-light)
            view_layout: { grid-area: data }
        view_layout:
          grid-area: right

      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 200
              bar_height: 24
              color: var(--lcards-gray-medium)
            inner_segment:
              bar_width: 52
              bar_height: 8
              color: var(--lcards-orange-medium)
        view_layout:
          grid-area: footer
```
:::

## Environmental

A shaped temperature slider, a humidity gauge, a status grid and a temperature history chart.

<video class="doc-video" src="/gallery/environmental.webm" poster="/gallery/environmental.webp" title="Environmental dashboard: a shaped temperature slider, a humidity gauge, a climate grid and a temperature chart" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Environmental: a shaped temperature slider, a humidity gauge, a status grid and
# a temperature history chart. Uses lcards_test_* helpers and a
# temperature sensor; swap in your own entities.
title: Environmental
views:
  - title: Environmental
    path: environmental
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 170px minmax(0, 1fr) minmax(0, 1fr)
      grid-template-rows: 64px 140px 140px minmax(0, 1fr) 64px
      grid-template-areas: |
        "header header header"
        "side   temp   humid"
        "side   grid   grid"
        "side   chart  chart"
        "footer footer footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          segment:
            bar_width: 170
            bar_height: 22
        text:
          title:
            content: ENVIRONMENTAL CONTROL
            position: bottom-right
            font_size: 24
            color: var(--lcards-orange)
        view_layout:
          grid-area: header
      - type: custom:lcards-button
        preset: panel-dark
        view_layout:
          grid-area: side
      - type: custom:lcards-slider
        entity: input_number.lcards_test_temperature
        preset: shaped-horizontal
        component: shaped
        text:
          name:
            content: DECK 1
        view_layout:
          grid-area: temp
      - type: custom:lcards-slider
        entity: input_number.lcards_test_humidity
        preset: gauge-basic
        view_layout:
          grid-area: humid
      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SECTION, TEMPERATURE, HUMIDITY, AIR]
            header: true
          - [DECK 1, "{{ states('input_number.lcards_test_temperature') }} °C", "{{ states('input_number.lcards_test_humidity') | int }} %", NOMINAL]
          - [DECK 2, "{{ states('sensor.desk_sensor_temperature') }} °C", "{{ states('input_number.lcards_test_humidity') | int }} %", NOMINAL]
        grid:
          grid-template-columns: 1fr 1fr 1fr 1fr
          gap: 4px
        style:
          font_size: 18px
        columns:
          - style:
              align: left
              color: var(--lcars-orange)
        view_layout:
          grid-area: grid
      - type: custom:lcards-chart
        sources:
          - entity: sensor.desk_sensor_temperature
            name: Deck 2 temperature
        view_layout:
          grid-area: chart
      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          segment:
            bar_width: 170
            bar_height: 22
        view_layout:
          grid-area: footer
```
:::

## Security

Door and light toggles whose labels follow their state, a [select menu](../cards/select-menu/) for the security mode, a D-pad stepping a value (a stand-in for a camera pan), a status grid and a decorative data block.

<video class="doc-video" src="/gallery/security.webm" poster="/gallery/security.webp" title="Security dashboard: toggle buttons, a mode selector, a status grid, a D-pad, a slider and a block of decorative LCARS numbers" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Security: door and light controls, a security mode selector, a D-pad (here it
# steps a helper, standing in for a camera pan) and a status grid. Uses the
# lcards_test_* helpers; swap in your own locks, lights, cameras and modes.
title: Security
views:
  - title: Security
    path: security
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 170px minmax(0, 1fr) 320px
      grid-template-rows: 64px 60px 60px 60px 90px minmax(0, 1fr) 64px
      grid-template-areas: |
        "header header header"
        "nav1   status dpad"
        "nav2   status dpad"
        "nav3   status dpad"
        "mode   status pan"
        "mode   deco   deco"
        "footer footer footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          segment:
            bar_width: 170
            bar_height: 22
        text:
          title:
            content: SECURITY
            position: bottom-right
            font_size: 24
            color: var(--lcards-orange)
        view_layout:
          grid-area: header
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_doors
        text:
          name:
            content: "{{ 'DOORS OPEN' if is_state('input_boolean.lcards_test_doors', 'on') else 'DOORS SECURED' }}"
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav1
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_lights
        text:
          name:
            content: EXTERIOR LIGHTS
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav2
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_toggle
        text:
          name:
            content: INTRUDER ALERT
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav3
      - type: custom:lcards-select-menu
        entity: input_select.lcards_test_mode
        preset: filled
        view_layout:
          grid-area: mode
      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SECTOR, STATUS]
            header: true
          - [MAIN DOORS, "{{ 'OPEN' if is_state('input_boolean.lcards_test_doors', 'on') else 'SECURED' }}"]
          - [EXTERIOR, "{{ 'LIT' if is_state('input_boolean.lcards_test_lights', 'on') else 'DARK' }}"]
          - [INTRUDERS, "{{ 'DETECTED' if is_state('input_boolean.lcards_test_toggle', 'on') else 'NONE' }}"]
          - [MODE, input_select.lcards_test_mode]
          - [CAMERA PAN, "{{ states('input_number.lcards_test_value') | int }} °"]
        grid:
          grid-template-columns: 1fr 1fr
          grid-auto-rows: 42px
          align-content: start
          gap: 4px
        style:
          font_size: 18px
        columns:
          - style:
              align: left
              color: var(--lcars-orange)
        view_layout:
          grid-area: status
      - type: custom:lcards-button
        component: dpad
        dpad:
          segments:
            default:
              style:
                fill:
                  default: var(--lcards-gray)
                  active: var(--lcards-orange)
            left:
              tap_action:
                action: perform-action
                service: input_number.decrement
                target:
                  entity_id: input_number.lcards_test_value
            right:
              tap_action:
                action: perform-action
                service: input_number.increment
                target:
                  entity_id: input_number.lcards_test_value
        view_layout:
          grid-area: dpad
      - type: custom:lcards-slider
        entity: input_number.lcards_test_value
        preset: pills-basic
        view_layout:
          grid-area: pan
      - type: custom:lcards-data-grid
        data_mode: decorative
        format: mixed
        grid:
          grid-template-rows: repeat(5, auto)
          grid-template-columns: repeat(10, minmax(50px, 1fr))
          gap: 0px
        style:
          font_size: 18px
          color: var(--lcars-orange)
        animations:
          - preset: cascade
        view_layout:
          grid-area: deco
      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          segment:
            bar_width: 170
            bar_height: 22
        view_layout:
          grid-area: footer
```
:::

## Alert mode

Buttons that raise and clear an [alert mode](../core/alert-mode) through the `lcards.*` [actions](../configuration/ha-actions), beside an everyday systems screen. The [alert overlay](../cards/alert-overlay/) covers the view with the symbol for the active alert: red, then yellow.

<video class="doc-video" src="/gallery/alert.webm" poster="/gallery/alert.webp" title="Alert dashboard: alert buttons beside a systems table, a data cascade and a chart; red alert covers it with the red overlay, then yellow alert with the yellow one" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Alert mode: buttons that raise and clear LCARdS alert modes (the lcards.* actions
# recolour every LCARdS dashboard) beside an everyday systems screen, and the alert
# overlay that covers the view while an alert is active.
title: Alert Mode
views:
  - title: Alert
    path: alert
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 170px minmax(0, 1fr) minmax(0, 1fr)
      grid-template-rows: 64px 70px 70px 70px 70px minmax(0, 1fr) 64px
      grid-template-areas: |
        "header header header"
        "red    status status"
        "yellow status status"
        "blue   status status"
        "clear  status status"
        "filler grid   chart"
        "footer footer footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          segment:
            bar_width: 170
            bar_height: 22
        text:
          title:
            content: ALERT STATUS
            position: bottom-right
            font_size: 24
            color: var(--lcards-orange)
        view_layout:
          grid-area: header
      # Shown over the view while an alert is active (no size: 60% x 50% of the screen).
      - type: custom:lcards-alert-overlay
        view_layout:
          grid-area: status
      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SYSTEM, STATUS, LEVEL]
            header: true
          - [MAIN POWER, "{{ 'ONLINE' if states('input_number.lcards_test_power') | int > 20 else 'LOW' }}", "{{ states('input_number.lcards_test_power') | int }} %"]
          - [SHIELDS, "{{ 'RAISED' if states('input_number.lcards_test_shields') | int > 0 else 'DOWN' }}", "{{ states('input_number.lcards_test_shields') | int }} %"]
          - [DOORS, "{{ 'OPEN' if is_state('input_boolean.lcards_test_doors', 'on') else 'SECURED' }}", ""]
          - [MODE, input_select.lcards_test_mode, ""]
        grid:
          grid-template-columns: 2fr 1fr 1fr
          grid-template-rows: repeat(5, min-content)
          gap: 6px
        style:
          font_size: 22px
        columns:
          - style:
              align: left
              color: var(--lcars-orange)
          - style:
              align: right
          - style:
              align: right
        view_layout:
          grid-area: status
      - type: custom:lcards-data-grid
        data_mode: decorative
        format: digit
        refresh_interval: 1500
        refresh_cells: 0.2
        grid:
          grid-template-rows: repeat(6, auto)
          grid-template-columns: repeat(6, 1fr)
          gap: 0px
        style:
          font_size: 20px
          color: var(--lcars-blue)
        view_layout:
          grid-area: grid
      - type: custom:lcards-chart
        chart_type: line
        graph_span: 12h
        sources:
          - entity: sensor.desk_sensor_temperature
            name: Deck 4
        view_layout:
          grid-area: chart
      - type: custom:lcards-button
        preset: filled
        style:
          card:
            color:
              background:
                default: var(--lcars-alert-red, #cc0000)
        text:
          name:
            content: RED ALERT
        tap_action:
          action: perform-action
          service: lcards.red_alert
        view_layout:
          grid-area: red
      - type: custom:lcards-button
        preset: filled
        style:
          card:
            color:
              background:
                default: var(--lcars-alert-yellow, #ffcc00)
        text:
          name:
            content: YELLOW ALERT
        tap_action:
          action: perform-action
          service: lcards.yellow_alert
        view_layout:
          grid-area: yellow
      - type: custom:lcards-button
        preset: filled
        style:
          card:
            color:
              background:
                default: var(--lcars-alert-blue, #3366ff)
        text:
          name:
            content: BLUE ALERT
        tap_action:
          action: perform-action
          service: lcards.blue_alert
        view_layout:
          grid-area: blue
      - type: custom:lcards-button
        preset: filled
        text:
          name:
            content: STAND DOWN
        tap_action:
          action: perform-action
          service: lcards.clear_alert
        view_layout:
          grid-area: clear
      - type: custom:lcards-button
        preset: panel-dark
        view_layout:
          grid-area: filler
      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          segment:
            bar_width: 170
            bar_height: 22
        view_layout:
          grid-area: footer
```
:::

## Picard era

Later LCARS screens (as on the USS Titan) use thinner, double-ringed frames, square-ended buttons, cooler blues and greys, and dense readouts with small orange accents. These two use the same cards in that style.

### Operations

Segmented double elbows, filled buttons that light up with their state, a [select menu](../cards/select-menu/) in the outline style, a cascade of changing hex values, a status table and two Picard sliders.

<video class="doc-video" src="/gallery/titan-operations.webm" poster="/gallery/titan-operations.webp" title="Operations dashboard: grey double elbows with orange accents framing light and door buttons, a mode selector, a blue cascade of hex numbers, a status table, two vertical Picard sliders and a temperature history" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Titan Operations: the Picard-era look (segmented double elbows, square-ended
# filled and outline buttons, Picard sliders, blue data cascades with orange accents).
# Uses lcards_test_* helpers and a temperature sensor; swap in your own entities.
title: Titan Operations
views:
  - title: Operations
    path: operations
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 210px minmax(0, 1fr) minmax(0, 1fr) 130px 130px
      grid-template-rows: 80px 52px 52px 52px 52px 140px minmax(0, 1fr) 80px
      grid-template-areas: |
        "header  header  header  header  header"
        "b1      cascade cascade power   shields"
        "b2      cascade cascade power   shields"
        "menu    cascade cascade power   shields"
        "menu    status  status  power   shields"
        "menu    status  status  power   shields"
        "chart   chart   chart   chart   chart"
        "footer  footer  footer  footer  footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 210
              bar_height: 24
              color: var(--lcards-gray-medium)
            inner_segment:
              bar_width: 48
              bar_height: 8
              color: var(--lcards-orange-medium)
        text:
          title:
            content: OPERATIONS · DECK 4
            position: bottom-right
            font_size: 26
            color: var(--lcards-blue-light)
        view_layout:
          grid-area: header
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_lights
        style:
          card:
            color:
              background:
                active: var(--lcards-orange)
                inactive: var(--lcards-gray-medium-dark)
        text:
          name:
            content: LIGHTS
        tap_action:
          action: toggle
        view_layout:
          grid-area: b1
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_doors
        style:
          card:
            color:
              background:
                active: var(--lcards-orange)
                inactive: var(--lcards-gray-medium-dark)
        text:
          name:
            content: DOORS
        tap_action:
          action: toggle
        view_layout:
          grid-area: b2
      - type: custom:lcards-data-grid
        data_mode: decorative
        format: hex
        refresh_interval: 1500
        refresh_cells: 0.15
        grid:
          grid-template-rows: repeat(4, auto)
          grid-template-columns: repeat(8, 1fr)
          gap: 0px
        columns:
          - format: digit
          - format: digit
        style:
          font_size: 22px
          color: var(--lcards-blue-light)
        highlight_changes:
          preset: pulse
          duration: 400
        view_layout:
          grid-area: cascade
      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SYSTEM, STATUS, LEVEL]
            header: true
          - [MAIN POWER, "{{ 'ONLINE' if states('input_number.lcards_test_power') | int > 20 else 'LOW' }}", "{{ states('input_number.lcards_test_power') | int }} %"]
          - [SHIELDS, "{{ 'RAISED' if states('input_number.lcards_test_shields') | int > 0 else 'DOWN' }}", "{{ states('input_number.lcards_test_shields') | int }} %"]
          - [MODE, input_select.lcards_test_mode, ""]
        grid:
          grid-template-columns: 2fr 1fr 1fr
          grid-template-rows: repeat(4, min-content)
          gap: 4px
        style:
          font_size: 18px
          color: var(--lcards-blue-light)
        columns:
          - style:
              align: left
              color: var(--lcards-orange)
          - style:
              align: right
          - style:
              align: right
        view_layout:
          grid-area: status
      - type: custom:lcards-slider
        entity: input_number.lcards_test_power
        preset: picard-gauge-vertical
        component: picard
        view_layout:
          grid-area: power
      - type: custom:lcards-slider
        entity: input_number.lcards_test_shields
        preset: picard-gauge-vertical
        component: picard
        view_layout:
          grid-area: shields
      - type: custom:lcards-select-menu
        entity: input_select.lcards_test_mode
        preset: outline
        grid:
          columns: 1
          gap: 6px
        view_layout:
          grid-area: menu
      - type: custom:lcards-chart
        chart_type: area
        graph_span: 24h
        sources:
          - entity: sensor.desk_sensor_temperature
            name: Deck 4
        style:
          colors:
            series:
              - var(--lcards-blue-light)
          fill:
            type: gradient
            gradient:
              opacityFrom: 0.45
              opacityTo: 0.02
        view_layout:
          grid-area: chart
      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 210
              bar_height: 24
              color: var(--lcards-gray-medium)
            inner_segment:
              bar_width: 48
              bar_height: 8
              color: var(--lcards-orange-medium)
        view_layout:
          grid-area: footer
```
:::

### Sciences

Segmented [frames](../cards/elbow/#frame-type) around a history chart with a smoothed [data source](../core/datasources/) trend and a set of radial gauges, a sensor table and hourly averages.

<video class="doc-video" src="/gallery/sciences.webm" poster="/gallery/sciences.webp" title="Sciences dashboard: a framed temperature history with a smoothed trend line, framed radial gauges for power, shields and humidity, a sensor table and a column chart of hourly averages" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Sciences: Picard-era readouts. Segmented frames around a history chart and a set of
# radial gauges, a sensor table and hourly averages, in cool blues and greys with
# orange accents. Uses lcards_test_* helpers and a temperature sensor.
title: Sciences
views:
  - title: Sciences
    path: sciences
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 8px
      grid-template-columns: minmax(0, 1.6fr) minmax(0, 1fr)
      grid-template-rows: 80px minmax(0, 1.3fr) minmax(0, 1fr) 70px
      grid-template-areas: |
        "header  header"
        "history gauges"
        "table   bars"
        "footer  footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-right
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 160
              bar_height: 24
              color: var(--lcards-blue-medium-light)
            inner_segment:
              bar_width: 40
              bar_height: 8
              color: var(--lcards-orange-medium)
        text:
          title:
            content: SCIENCES · SENSOR ANALYSIS
            position: bottom-left
            font_size: 26
            color: var(--lcards-blue-lightest)
        view_layout:
          grid-area: header

      # History: a segmented frame with the chart inside it.
      - type: custom:lcards-elbow
        elbow:
          type: frame
          style: segmented
          segment:
            color: var(--lcards-gray-medium)
          frame:
            bar_width: 14
            bar_height: 10
            segments:
              gap: 5
              inner_frame:
                bar_width: 4
                color: var(--lcards-blue-medium-light)
        view_layout:
          grid-area: history
      - type: custom:lcards-chart
        chart_type: area
        graph_span: 24h
        data_sources:
          deck_temp:
            entity: sensor.desk_sensor_temperature
            history:
              hours: 24
            processing:
              smoothed:
                type: smooth
                method: exponential
                alpha: 0.15
        sources:
          - datasource: deck_temp
            name: Deck 4
          - datasource: deck_temp
            buffer: smoothed
            name: Trend
        style:
          colors:
            series:
              - var(--lcards-blue-light)
              - var(--lcards-orange-medium)
          fill:
            type: gradient
            gradient:
              opacityFrom: 0.4
              opacityTo: 0.02
          legend:
            show: true
        view_layout:
          grid-area: history
          margin: 30px 34px

      # Gauges: radial bars for the live levels, in a matching frame.
      - type: custom:lcards-elbow
        elbow:
          type: frame
          style: segmented
          segment:
            color: var(--lcards-gray-medium)
          frame:
            bar_width: 14
            bar_height: 10
            segments:
              gap: 5
              inner_frame:
                bar_width: 4
                color: var(--lcards-orange-medium)
        view_layout:
          grid-area: gauges
      - type: custom:lcards-chart
        chart_type: radialBar
        sources:
          - entity: input_number.lcards_test_power
            name: Power
          - entity: input_number.lcards_test_shields
            name: Shields
          - entity: input_number.lcards_test_humidity
            name: Humidity
        style:
          colors:
            series:
              - var(--lcards-orange-medium)
              - var(--lcards-blue-light)
              - var(--lcards-blue-medium-light)
          legend:
            show: true
          chart_options:
            plotOptions:
              radialBar:
                startAngle: -135
                endAngle: 135
                hollow:
                  size: 35%
        view_layout:
          grid-area: gauges
          margin: 30px 34px

      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SENSOR, READING, STATUS]
            header: true
          - [DECK 4 TEMP, sensor.desk_sensor_temperature, NOMINAL]
          - [CABIN TEMP, input_number.lcards_test_temperature, NOMINAL]
          - [HUMIDITY, input_number.lcards_test_humidity, "{{ 'HIGH' if states('input_number.lcards_test_humidity') | int > 60 else 'NOMINAL' }}"]
          - [POWER, input_number.lcards_test_power, "{{ 'ONLINE' if states('input_number.lcards_test_power') | int > 20 else 'LOW' }}"]
        grid:
          grid-template-columns: 2fr 1fr 1fr
          grid-template-rows: repeat(5, min-content)
          gap: 6px
        style:
          font_size: 20px
          color: var(--lcards-blue-lightest)
        columns:
          - style:
              align: left
              color: var(--lcards-orange-medium)
          - style:
              align: right
          - style:
              align: right
              color: var(--lcards-blue-light)
        view_layout:
          grid-area: table

      - type: custom:lcards-chart
        chart_type: column
        graph_span: 12h
        sources:
          - entity: sensor.desk_sensor_temperature
            name: Hourly average
            group_by:
              func: avg
              duration: 1h
        style:
          colors:
            series:
              - var(--lcards-blue-medium-light)
        view_layout:
          grid-area: bars

      - type: custom:lcards-elbow
        elbow:
          type: footer-right
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 160
              bar_height: 24
              color: var(--lcards-blue-medium-light)
            inner_segment:
              bar_width: 40
              bar_height: 8
              color: var(--lcards-orange-medium)
        view_layout:
          grid-area: footer
```
:::
