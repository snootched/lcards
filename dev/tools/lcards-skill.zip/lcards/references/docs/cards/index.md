# The Fleet

:::: tabs
=== Button

#### **`lcards-button`**
All standard LCARS buttons, plus advanced multi-segment controls.

![Button Card](/img/lcards-button.png)

- Built-in preset library: lozenge, bullet, capped, outline, pill, text, and more
- **Component mode**: embed SVG components (D-pad, Alert, custom shapes) with per-segment interactivity
- Canvas-based **background animations**: stackable layers with zoom and pan
- Rules Engine integration: styles hot-patched at runtime

[Button Documentation](button/)

=== Elbow

#### **`lcards-elbow`**
Classic LCARS corner designs.

![Elbow Card](/img/lcards-elbow.png)

- Built-in preset library: `header-left`, `header-right`, `footer-left`, `footer-right` and more
- **Simple** and **segmented** (Picard-style double elbow) styles
- Fully configurable LCARS arc geometry or diagonal-cut corners
- Symbiont support: embed other HA cards inside the elbow area
- Animated 'textures' available

[Elbow Documentation](elbow/)

=== Slider

#### **`lcards-slider`**
Interactive sliders for display and control.

![Slider Card](/img/lcards-slider.gif)

- Built-in presets: **pills** (segmented bar) and **gauge** (ruler with tick marks)
- Horizontal and vertical orientations with independent fill and control inversion
- Separate min/max for display range vs. control range
- Domain auto-detection: interactive for controllable domains, display-only for sensors

[Slider Documentation](slider-card/)

=== Select Menu

#### **`lcards-select-menu`**
Grid of option buttons built from `input_select`|`select` entities or custom options.

![Select Card](/img/lcards-select.gif)

- Creates a grid of buttons from an `input_select`|`select` entity for an easy to use options selector
- Fully customizable layout with CSS grid
- Ability to re-order options, customize labels, and even add additional custom options to the list
- Fully customizable actions with per-entry overrides

[Select Menu Documentation](select-menu/)

=== Data Grid

#### **`lcards-data-grid`**
LCARS data grids with cascade animations.

![Data Grid Card](/img/lcards-data-grid.gif)

- **Data mode**: real entity states, attributes, or template values
- **Decorative mode**: cascading generated data for aesthetics
- LCARS-style cascade animation with built-in speed presets
- CSS Grid layout with full style cascading

[Data Grid Documentation](data-grid/)

=== Chart

#### **`lcards-chart`**
LCARdS integrated charting via ApexCharts.

![Chart card: a 24-hour temperature history as an orange area with a gradient fill, a blue smoothed line from a data source, and a dashed comfort threshold](/img/cards/chart.webp)

- 15+ chart types: line, area, bar, pie, scatter, heatmap, radar, and more
- Entities, long-term statistics or data sources, with smoothing, min/max and rolling statistics
- Threshold lines, gradient fills and theme colours that follow alert modes

[Chart Documentation](chart/)

=== Alert Overlay

#### **`lcards-alert-overlay`**
Full-screen dashboard overlay reacting to alert state.

<video class="doc-video" src="/gallery/alert.webm" poster="/img/cards/alert-overlay.webp" title="Alert overlay: red alert covers a dashboard with a blurred backdrop and the red alert symbol, then yellow alert" autoplay loop muted playsinline></video>

- Activates automatically when `input_select.lcards_alert_mode` changes (for example from `lcards.red_alert`)
- Full-screen backdrop with blur + tint layers
- Configurable per-condition content card, position, and size
- Content is interactive, with tap outside to dismiss

[Alert Overlay Documentation](alert-overlay/)

=== MSD

#### **`lcards-msd-card`**
Create your own Master Systems Display with controls and routable lines.

<video class="doc-video" src="/img/cards/msd-motion.webm" poster="/img/cards/msd.webp" title="MSD card: shield arcs around a starship blueprint turn orange, then red, as shields drop, with three controls joined to the ship by routed lines" autoplay loop muted playsinline></video>

- Embed any HA card as a positioned **control overlay**
- **Line overlays**: SVG lines with smart routing and avoid-obstacle algorithms
- **Studio Editor**: visual configuration with live preview and drag-to-reposition
- Animate lines independently with rules

[MSD Documentation](msd/)

=== Layout Card

#### **`lcards-layout-card`**
A grid of cards inside one card: build a sub-grid anywhere.

![Layout card: an LCARS frame of header and footer elbows around three buttons, a block of data cascade numbers and a vertical Picard-style slider](/img/cards/layout-card.webp)

- CSS Grid with named areas: place each card by area, like the Layout View
- **Layout Studio**: a full-screen visual editor to draw areas and place cards
- Nest layout cards for deeper sub-grids
- Child cards keep Home Assistant's own visibility conditions

[Layout Card Documentation](layout-card/)

::::

## Common Card Features

Features and concepts shared across the card system:

| Topic | What it covers |
|-------|---------------|
| [Common Card Properties](common.md) | `id`, `tags`, `height`, `width`, `grid_options`, properties shared by all cards |
| [Colours](../core/colours.md) | Colour formats, state-based colour system, resolution order |
| [Actions](../core/actions.md) | `tap_action`, `hold_action`, `double_tap_action`, all action types and options |
| [Text Fields](../core/text-fields.md) | Multi-field text system: placement, fonts, colour, templates |
| [Templates](../core/templates/) | Dynamic content: JS, Jinja2, LCARdS token data source templates |
| [Animations](../core/animations.md) | Per-card animations with multiple trigger types |
| [Background Animations](../core/effects/background-animations.md) | Canvas-based animated backgrounds (grid, starfield, nebula, etc.) |
| [Sound Effects](../core/sounds.md) | LCARS-style audio feedback for interactions and alerts |
| [Rules Engine](../core/rules/) | Advanced conditional system for styling applied across cards |
| [Data Sources](../core/datasources/) | Subscribes to HA Entity to provide history and processing pipelines for cards to consume |
| [Themes](../core/themes/) | Built-in token-based theming for providing colour, sizing etc. |
