# Alert Mode

Alert Mode gives LCARdS coordinated, dashboard-wide visual states that match the classic Star Trek red/yellow alert experience.

Alert mode is more than a colour change; it shifts the entire dashboard UI together:

- **Theme colours transform**: the whole HA UI palette shifts; hues, saturation, and token values rotate to match the alert level across every element on screen. All transform parameters are fully configurable per alert mode via the **Alert Mode Lab** in the LCARdS Config Panel.
- **Sound plays**: the Sound Manager fires the matching alert audio scheme automatically.
- **Alert Overlay activates**: the `lcards-alert-overlay` card reacts and displays its full-screen backdrop and content card for the triggered alert condition.
- **Rules-driven animations**: cards and MSD overlays can be configured to pulse, flash, or animate when a specific alert level is active. This is opt-in via the Rules Engine, not automatic.
- **HA helpers stay in sync**: the `input_select.lcards_alert_mode` helper always reflects the current state, so HA automations can both trigger and react to alert level changes.

---

## Alert Levels

| Level | Description |
|-------|-------------|
| `green` | Normal operation: default state |
| `yellow` | Caution / yellow alert |
| `red` | Red alert: maximum urgency |
| `blue` | Blue alert (specific condition) |
| `gray` | Reduced / standby mode |
| `black` | Black alert |

---

## Triggering Alert Mode

Alert mode can be triggered from multiple places:

:::: tabs
=== Card Action

Set a tap action on any card to call the `input_select.select_option` service:

```yaml
tap_action:
  action: call-service
  service: input_select.select_option
  service_data:
    entity_id: input_select.lcards_alert_mode
    option: red_alert
```

=== HA Automation

Use the helper in any automation; changes all browsers simultaneously:

```yaml
action:
  - service: input_select.select_option
    data:
      entity_id: input_select.lcards_alert_mode
      option: yellow_alert
```

=== LCARdS Services

Use the dedicated `lcards.*` services to get **per-device or per-user targeting**.
When targeting fields are present the `input_select` helper is **not** written; the
alert is applied as a local, transient change on matching sessions only.

```yaml alternatives
# All devices (same as input_select route, but via the lcards service)
action: lcards.red_alert

# Specific devices by friendly display name
action: lcards.red_alert
data:
  target_device_names:
    - Kitchen Tablet
    - Hallway Display

# Specific device by UUID
action: lcards.red_alert
data:
  target_device_ids:
    - "a1b2c3d4-e5f6-7890-abcd-ef1234567890"

# All sessions belonging to a specific HA user
action: lcards.yellow_alert
data:
  target_user_names:
    - jane

# Clear alert on one device only
action: lcards.clear_alert
data:
  target_device_names:
    - Bedroom Kiosk
```

> Get your device's UUID and name via `window.lcards.targeting.getMyIds()` in the browser console.
> See [HA Service Targeting](/development/backend-api#ha-service-targeting) for the full field reference.

=== Browser Console

Use the `window.lcards.alert` console API from the browser dev tools:

```javascript
// Mode shortcuts
window.lcards.alert.red();
window.lcards.alert.yellow();
window.lcards.alert.blue();
window.lcards.alert.gray();
window.lcards.alert.black();
window.lcards.alert.off();       // Reset to normal (green)

// Set / get by mode name
window.lcards.alert.set('red_alert');
window.lcards.alert.get();       // → 'red_alert'

// Live parameter tuning (see also Alert Mode Lab)
window.lcards.alert.config.setParam('red_alert', 'saturationMultiplier', 1.5, true);
await window.lcards.alert.config.getTransform('red_alert');
await window.lcards.alert.config.reset('red_alert', true);
await window.lcards.alert.config.export();  // Export runtime overrides as JSON
```

> Root-level shortcuts `window.lcards.redAlert()`, `.yellowAlert()` etc. still exist and are kept for backward compatibility.

=== Config Panel

Pick a mode in the **LCARdS Alert Mode Lab** (LCARdS Config Panel > Theme Studio) and click **Apply live**.

::::
---

## Required Helper

Alert mode requires the `input_select.lcards_alert_mode` helper to be defined in Home Assistant.

The easiest way to create it is via the **Helpers** tab in the LCARdS Config Panel (one click to create all required helpers). Alternatively, add the following to `configuration.yaml`:

```yaml
input_select:
  lcards_alert_mode:
    name: LCARdS Alert Mode
    options:
      - green_alert
      - yellow_alert
      - red_alert
      - blue_alert
      - gray_alert
      - black_alert
    initial: green_alert
    icon: mdi:alert
```

::: tip
The **Helpers** tab in the Config Panel creates all LCARdS helpers (including this one) in a single click.
:::

---

## Configuring Alert Appearance

### Alert Mode Lab

The **Alert Mode Lab** tab in the LCARdS Config Panel is the primary tool for configuring how each alert level looks and behaves:

- Colour palette transforms: adjust hue rotation, saturation shift, and lightness for the full dashboard palette per alert level
- Preview transforms live before saving
- Configure sounds per alert level

### Alert Overlay Card

The `lcards-alert-overlay` card provides the full-screen backdrop and content card shown during an alert. Add one to every dashboard view that should react to alert modes, as the last card in the view:

```yaml
type: custom:lcards-alert-overlay
```

Backdrop layers, the content card, its position and size, and dismiss behaviour are all configurable; see [Alert Overlay Card](/cards/alert-overlay/) for the full reference.

### Rules-Driven Animations

Cards can be configured to animate when specific alert levels are active. This is done through the Rules Engine rather than automatically. Example:

```yaml
rules:
  - id: red-alert-pulse
    when:
      entity: input_select.lcards_alert_mode
      state: red_alert
    apply:
      animations:
        - tag: status-indicator
          preset: pulse
          loop: true
```

See [Rules Engine](rules/) for the full condition and apply reference.
