# Dashboard Gallery

Complete dashboards, not single cards: each one is a whole view built from LCARdS cards on a [Layout View](../cards/layout-view/), recorded in Home Assistant while its entities change (lights switch, levels move, alerts sound). Copy one, swap in your own entities, and build from there.

To use one:

1. Create a dashboard (**Settings > Dashboards > Add dashboard**), open it, then **Edit dashboard > Raw configuration editor**.
2. Paste the YAML and save.
3. Replace the `lcards_test_*` helpers and the sample temperature sensor with your own entities.
4. Paste your version into [Check Your Config](config-checker) before you save it.

They look best with an [HA-LCARS](https://github.com/th3jesta/ha-lcars) theme, and need no other custom cards.

## Bridge

An LCARS frame (header and footer elbows, a sidebar of buttons) around a status grid, two sliders, a toggle and a history chart.

<video class="doc-video" src="/gallery/bridge.webm" poster="/gallery/bridge.webp" title="Bridge dashboard: sidebar buttons, a status grid, power and shields sliders, a lights button and a temperature chart" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Bridge: an LCARS frame (header and footer elbows, a sidebar of buttons) around a
# main panel with a status grid, controls and a chart. Uses lcards_test_* helpers
# and a temperature sensor; swap in your own entities. Best with an HA-LCARS theme.
title: Bridge
views:
  - title: Bridge
    path: bridge
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 170px 1fr 1fr 1fr
      grid-template-rows: 64px 54px 54px 54px 54px 54px 1fr 64px
      grid-template-areas: |
        "header  header  header  header"
        "nav1    status  status  status"
        "nav2    status  status  status"
        "nav3    status  status  status"
        "nav4    power   shields lights"
        "nav5    power   shields lights"
        "filler  chart   chart   chart"
        "footer  footer  footer  footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          segment:
            bar_width: 170
            bar_height: 22
        text:
          title:
            content: BRIDGE OPERATIONS
            position: bottom-right
            font_size: 24
            color: var(--lcards-orange)
        view_layout:
          grid-area: header
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_toggle
        text:
          name:
            content: RED ALERT
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav1
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_lights
        text:
          name:
            content: LIGHTS
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav2
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_doors
        text:
          name:
            content: DOORS
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav3
      - type: custom:lcards-button
        preset: filled
        entity: input_select.lcards_test_mode
        text:
          name:
            content: MODE
        tap_action:
          action: more-info
        view_layout:
          grid-area: nav4
      - type: custom:lcards-button
        preset: filled
        entity: input_number.lcards_test_shields
        text:
          name:
            content: SHIELDS
        tap_action:
          action: more-info
        view_layout:
          grid-area: nav5
      - type: custom:lcards-button
        preset: panel-dark
        view_layout:
          grid-area: filler
      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SYSTEM, STATUS, LEVEL]
            header: true
          - [WARP CORE, "{{ 'ONLINE' if states('input_number.lcards_test_power') | float > 0 else 'OFFLINE' }}", "{{ states('input_number.lcards_test_power') | int }} %"]
          - [SHIELDS, "{{ 'RAISED' if states('input_number.lcards_test_shields') | float > 50 else 'LOW' }}", "{{ states('input_number.lcards_test_shields') | int }} %"]
          - [CABIN TEMP, NOMINAL, "{{ states('input_number.lcards_test_temperature') }} °C"]
        grid:
          grid-template-columns: 1fr 1fr 1fr
          gap: 4px
        style:
          font_size: 18px
        columns:
          - style:
              align: left
              color: var(--lcars-orange)
        view_layout:
          grid-area: status
      - type: custom:lcards-slider
        entity: input_number.lcards_test_power
        preset: pills-basic
        view_layout:
          grid-area: power
      - type: custom:lcards-slider
        entity: input_number.lcards_test_shields
        preset: gauge-basic
        view_layout:
          grid-area: shields
      - type: custom:lcards-button
        preset: lozenge
        entity: input_boolean.lcards_test_lights
        icon: mdi:lightbulb-group
        text:
          label:
            content: MAIN LIGHTS
            show: true
        tap_action:
          action: toggle
        view_layout:
          grid-area: lights
      - type: custom:lcards-chart
        sources:
          - entity: sensor.desk_sensor_temperature
            name: Deck temperature
        view_layout:
          grid-area: chart
      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          segment:
            bar_width: 170
            bar_height: 22
        view_layout:
          grid-area: footer
```
:::

## Engineering

A [Master Systems Display](../cards/msd/) of the built-in NCC-1701-A blueprint in a Picard-era frame. Shield arcs around the ship change colour with shield strength, and three controls are joined to the ship's own bridge, warp core and shuttle bay markers by routed lines. Square sidebar buttons, a tick band, a systems table and Picard sliders surround it.

<video class="doc-video" src="/gallery/engineering.webm" poster="/gallery/engineering.webp" title="Engineering dashboard: a ship blueprint inside shield arcs, with three square control buttons joined to it by lines, a column of square sidebar buttons, a tick band, a systems table, two Picard sliders and a data cascade" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Engineering: a Master Systems Display of the built-in NCC-1701-A blueprint inside a
# Picard-era frame. Shield arcs around the ship change colour with shield strength
# (the shield_* naming MSD Studio's Suggest Shield Bubble uses); controls are joined
# to the ship's own markers by routed lines. Square sidebar buttons, a tick band, a
# systems table and Picard sliders around it. Uses lcards_test_* helpers.
title: Engineering
views:
  - title: Engineering
    path: engineering
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 200px minmax(0, 1fr) 280px
      grid-template-rows: 80px minmax(0, 1fr) 44px 180px 80px
      grid-template-areas: |
        "header header header"
        "side   msd    right"
        "side   band   right"
        "side   lower  right"
        "footer footer footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 200
              bar_height: 24
              color: var(--lcards-gray-medium)
            inner_segment:
              bar_width: 52
              bar_height: 8
              color: var(--lcards-orange-medium)
        text:
          title:
            content: ENGINEERING · MAIN SYSTEMS
            position: bottom-right
            font_size: 26
            color: var(--lcards-orange)
        view_layout:
          grid-area: header

      # Sidebar: a stack of square buttons over a filler block.
      - type: custom:lcards-layout-card
        layout:
          grid-gap: 6px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: repeat(5, 56px) minmax(0, 1fr)
        cards:
          - type: custom:lcards-button
            preset: filled
            entity: input_boolean.lcards_test_toggle
            text:
              name:
                content: WARP CORE
            tap_action:
              action: toggle
          - type: custom:lcards-button
            preset: filled
            entity: input_boolean.lcards_test_lights
            text:
              name:
                content: MAIN LIGHTS
            tap_action:
              action: toggle
          - type: custom:lcards-button
            preset: filled
            entity: input_boolean.lcards_test_doors
            text:
              name:
                content: DOORS
            tap_action:
              action: toggle
          - type: custom:lcards-button
            preset: filled
            text:
              name:
                content: SENSORS
          - type: custom:lcards-button
            preset: filled
            text:
              name:
                content: LIFE SUPPORT
          - type: custom:lcards-button
            preset: panel-dark
        view_layout:
          grid-area: side

      # The ship, framed by a thin line.
      - type: custom:lcards-elbow
        elbow:
          type: frame
          segment:
            color: var(--lcards-gray-medium-dark)
          frame:
            bar_width: 3
            bar_height: 3
            outer_curve: 18
        view_layout:
          grid-area: msd
      - type: custom:lcards-msd-card
        msd:
          base_svg:
            source: builtin:ncc-1701-a-blue
          view_box: [180, 270, 1600, 720]
          overlays:
            - id: shield_fore
              type: shape
              kind: polyline
              entity: input_number.lcards_test_shields
              corner_style: miter
              points: [[1526, 431], [1553, 450], [1577, 470], [1598, 491], [1616, 512], [1631, 534], [1643, 556], [1651, 579], [1656, 602], [1658, 625], [1656, 648], [1651, 671], [1643, 694], [1631, 716], [1616, 738], [1598, 759], [1577, 780], [1553, 800], [1526, 819]]
              style:
                width: 6
                line_cap: round
                color:
                  default: "var(--lcards-blue-light)"
                  below:50: "var(--lcards-orange)"
                  below:20: "var(--lcars-alert-red, #cc0000)"
            - id: shield_starboard
              type: shape
              kind: polyline
              entity: input_number.lcards_test_shields
              corner_style: miter
              points: [[1374, 892], [1334, 905], [1292, 916], [1249, 926], [1204, 935], [1158, 942], [1111, 948], [1064, 952], [1016, 954], [968, 955], [920, 954], [872, 952], [825, 948], [778, 942], [732, 935], [687, 926], [644, 916], [602, 905], [562, 892]]
              style:
                width: 6
                line_cap: round
                color:
                  default: "var(--lcards-blue-light)"
                  below:50: "var(--lcards-orange)"
                  below:20: "var(--lcars-alert-red, #cc0000)"
            - id: shield_aft
              type: shape
              kind: polyline
              entity: input_number.lcards_test_shields
              corner_style: miter
              points: [[410, 819], [383, 800], [359, 780], [338, 759], [320, 738], [305, 716], [293, 694], [285, 671], [280, 648], [278, 625], [280, 602], [285, 579], [293, 556], [305, 534], [320, 512], [338, 491], [359, 470], [383, 450], [410, 431]]
              style:
                width: 6
                line_cap: round
                color:
                  default: "var(--lcards-blue-light)"
                  below:50: "var(--lcards-orange)"
                  below:20: "var(--lcars-alert-red, #cc0000)"
            - id: shield_port
              type: shape
              kind: polyline
              entity: input_number.lcards_test_shields
              corner_style: miter
              points: [[562, 358], [602, 345], [644, 334], [687, 324], [732, 315], [778, 308], [825, 302], [872, 298], [920, 296], [968, 295], [1016, 296], [1064, 298], [1111, 302], [1158, 308], [1204, 315], [1249, 324], [1292, 334], [1334, 345], [1374, 358]]
              style:
                width: 6
                line_cap: round
                color:
                  default: "var(--lcards-blue-light)"
                  below:50: "var(--lcards-orange)"
                  below:20: "var(--lcars-alert-red, #cc0000)"
            - id: bridge-ctl
              type: control
              attachment: top-left
              position: [190, 278]
              size: [340, 96]
              card:
                type: custom:lcards-button
                preset: filled
                entity: input_boolean.lcards_test_lights
                text:
                  name:
                    content: BRIDGE
                    font_size: 30
                tap_action:
                  action: toggle
            - id: core-ctl
              type: control
              attachment: top-left
              position: [190, 886]
              size: [340, 96]
              card:
                type: custom:lcards-button
                preset: filled
                entity: input_boolean.lcards_test_toggle
                text:
                  name:
                    content: WARP CORE
                    font_size: 30
                tap_action:
                  action: toggle
            - id: shuttle-ctl
              type: control
              attachment: top-left
              position: [1430, 886]
              size: [340, 96]
              card:
                type: custom:lcards-button
                preset: filled
                text:
                  name:
                    content: SHUTTLE BAY
                    font_size: 30
            - id: bridge-line
              type: line
              anchor: bridge-ctl
              attach_to: br
              route: auto
              corner_style: round
              style:
                color: var(--lcards-gray-medium-light)
                width: 3
            - id: core-line
              type: line
              anchor: core-ctl
              attach_to: wc
              route: auto
              corner_style: round
              style:
                color: var(--lcards-gray-medium-light)
                width: 3
            - id: shuttle-line
              type: line
              anchor: shuttle-ctl
              attach_to: sb
              route: auto
              corner_style: round
              style:
                color: var(--lcards-gray-medium-light)
                width: 3
        view_layout:
          grid-area: msd
          margin: 10px

      # A band of ticks (a pill slider) under the display.
      - type: custom:lcards-slider
        entity: input_number.lcards_test_power
        preset: pills-basic
        view_layout:
          grid-area: band

      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SYSTEM, STATUS, LEVEL]
            header: true
          - [WARP CORE, "{{ 'ONLINE' if is_state('input_boolean.lcards_test_toggle', 'on') else 'STANDBY' }}", "{{ states('input_number.lcards_test_power') | int }} %"]
          - [SHIELDS, "{{ 'RAISED' if states('input_number.lcards_test_shields') | int > 0 else 'DOWN' }}", "{{ states('input_number.lcards_test_shields') | int }} %"]
          - [MODE, input_select.lcards_test_mode, ""]
        grid:
          grid-template-columns: 2fr 1fr 1fr
          grid-template-rows: repeat(4, min-content)
          gap: 6px
        style:
          font_size: 20px
          color: var(--lcards-blue-light)
        columns:
          - style:
              align: left
              color: var(--lcards-orange)
          - style:
              align: right
          - style:
              align: right
        view_layout:
          grid-area: lower

      # Right: power and shields on Picard sliders, over a data cascade.
      - type: custom:lcards-layout-card
        layout:
          grid-gap: 6px
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr)
          grid-template-rows: minmax(0, 1.4fr) minmax(0, 1fr)
          grid-template-areas: |
            "power shields"
            "data  data"
        cards:
          - type: custom:lcards-slider
            entity: input_number.lcards_test_power
            preset: picard-gauge-vertical
            component: picard
            view_layout: { grid-area: power }
          - type: custom:lcards-slider
            entity: input_number.lcards_test_shields
            preset: picard-gauge-vertical
            component: picard
            view_layout: { grid-area: shields }
          - type: custom:lcards-data-grid
            data_mode: decorative
            format: digit
            refresh_interval: 2000
            refresh_cells: 0.2
            grid:
              grid-template-rows: repeat(6, auto)
              grid-template-columns: repeat(4, 1fr)
              gap: 0px
            style:
              font_size: 18px
              color: var(--lcards-gray-medium-light)
            view_layout: { grid-area: data }
        view_layout:
          grid-area: right

      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 200
              bar_height: 24
              color: var(--lcards-gray-medium)
            inner_segment:
              bar_width: 52
              bar_height: 8
              color: var(--lcards-orange-medium)
        view_layout:
          grid-area: footer
```
:::

## Environmental

A shaped temperature slider, a humidity gauge, a status grid and a temperature history chart.

<video class="doc-video" src="/gallery/environmental.webm" poster="/gallery/environmental.webp" title="Environmental dashboard: a shaped temperature slider, a humidity gauge, a climate grid and a temperature chart" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Environmental: a shaped temperature slider, a humidity gauge, a status grid and
# a temperature history chart. Uses lcards_test_* helpers and a
# temperature sensor; swap in your own entities.
title: Environmental
views:
  - title: Environmental
    path: environmental
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 170px minmax(0, 1fr) minmax(0, 1fr)
      grid-template-rows: 64px 140px 140px minmax(0, 1fr) 64px
      grid-template-areas: |
        "header header header"
        "side   temp   humid"
        "side   grid   grid"
        "side   chart  chart"
        "footer footer footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          segment:
            bar_width: 170
            bar_height: 22
        text:
          title:
            content: ENVIRONMENTAL CONTROL
            position: bottom-right
            font_size: 24
            color: var(--lcards-orange)
        view_layout:
          grid-area: header
      - type: custom:lcards-button
        preset: panel-dark
        view_layout:
          grid-area: side
      - type: custom:lcards-slider
        entity: input_number.lcards_test_temperature
        preset: shaped-horizontal
        component: shaped
        text:
          name:
            content: DECK 1
        view_layout:
          grid-area: temp
      - type: custom:lcards-slider
        entity: input_number.lcards_test_humidity
        preset: gauge-basic
        view_layout:
          grid-area: humid
      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SECTION, TEMPERATURE, HUMIDITY, AIR]
            header: true
          - [DECK 1, "{{ states('input_number.lcards_test_temperature') }} °C", "{{ states('input_number.lcards_test_humidity') | int }} %", NOMINAL]
          - [DECK 2, "{{ states('sensor.desk_sensor_temperature') }} °C", "{{ states('input_number.lcards_test_humidity') | int }} %", NOMINAL]
        grid:
          grid-template-columns: 1fr 1fr 1fr 1fr
          gap: 4px
        style:
          font_size: 18px
        columns:
          - style:
              align: left
              color: var(--lcars-orange)
        view_layout:
          grid-area: grid
      - type: custom:lcards-chart
        sources:
          - entity: sensor.desk_sensor_temperature
            name: Deck 2 temperature
        view_layout:
          grid-area: chart
      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          segment:
            bar_width: 170
            bar_height: 22
        view_layout:
          grid-area: footer
```
:::

## Security

Door and light toggles whose labels follow their state, a [select menu](../cards/select-menu/) for the security mode, a D-pad stepping a value (a stand-in for a camera pan), a status grid and a wall of sector tiles, one framed feed per sector with its live status.

<video class="doc-video" src="/gallery/security.webm" poster="/gallery/security.webp" title="Security dashboard: toggle buttons, a mode selector, a status grid, a D-pad, a slider and four framed sector tiles with grid backgrounds and their status" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Security: door and light controls, a security mode selector, a D-pad (here it
# steps a helper, standing in for a camera pan), a status grid and sector tiles. Uses the
# lcards_test_* helpers; swap in your own locks, lights, cameras and modes.
title: Security
views:
  - title: Security
    path: security
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 170px minmax(0, 1fr) 320px
      grid-template-rows: 64px 60px 60px 60px 90px minmax(0, 1fr) 64px
      grid-template-areas: |
        "header header header"
        "nav1   status dpad"
        "nav2   status dpad"
        "nav3   status dpad"
        "mode   status pan"
        "mode   deco   deco"
        "footer footer footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          segment:
            bar_width: 170
            bar_height: 22
        text:
          title:
            content: SECURITY
            position: bottom-right
            font_size: 24
            color: var(--lcards-orange)
        view_layout:
          grid-area: header
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_doors
        text:
          name:
            content: "{{ 'DOORS OPEN' if is_state('input_boolean.lcards_test_doors', 'on') else 'DOORS SECURED' }}"
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav1
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_lights
        text:
          name:
            content: EXTERIOR LIGHTS
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav2
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_toggle
        text:
          name:
            content: INTRUDER ALERT
        tap_action:
          action: toggle
        view_layout:
          grid-area: nav3
      - type: custom:lcards-select-menu
        entity: input_select.lcards_test_mode
        preset: filled
        view_layout:
          grid-area: mode
      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SECTOR, STATUS]
            header: true
          - [MAIN DOORS, "{{ 'OPEN' if is_state('input_boolean.lcards_test_doors', 'on') else 'SECURED' }}"]
          - [EXTERIOR, "{{ 'LIT' if is_state('input_boolean.lcards_test_lights', 'on') else 'DARK' }}"]
          - [INTRUDERS, "{{ 'DETECTED' if is_state('input_boolean.lcards_test_toggle', 'on') else 'NONE' }}"]
          - [MODE, input_select.lcards_test_mode]
          - [CAMERA PAN, "{{ states('input_number.lcards_test_value') | int }} °"]
        grid:
          grid-template-columns: 1fr 1fr
          grid-auto-rows: 42px
          align-content: start
          gap: 4px
        style:
          font_size: 18px
        columns:
          - style:
              align: left
              color: var(--lcars-orange)
        view_layout:
          grid-area: status
      - type: custom:lcards-button
        component: dpad
        dpad:
          segments:
            default:
              style:
                fill:
                  default: var(--lcards-gray)
                  active: var(--lcards-orange)
            left:
              tap_action:
                action: perform-action
                service: input_number.decrement
                target:
                  entity_id: input_number.lcards_test_value
            right:
              tap_action:
                action: perform-action
                service: input_number.increment
                target:
                  entity_id: input_number.lcards_test_value
        view_layout:
          grid-area: dpad
      - type: custom:lcards-slider
        entity: input_number.lcards_test_value
        preset: pills-basic
        view_layout:
          grid-area: pan
      # Sector tiles: one framed tile per sector, like a camera wall.
      - type: custom:lcards-layout-card
        layout:
          grid-gap: 10px
          grid-template-columns: repeat(4, minmax(0, 1fr))
          grid-template-rows: minmax(0, 1fr)
        cards:
          - type: custom:lcards-elbow
            elbow:
              type: frame
              segment: { color: theme:colors.card.topColor }
              frame: { bar_width: 4, bar_height: 4, outer_curve: 10 }
            background_animation:
              inset: auto
              effects: [{ preset: grid }]
            symbiont:
              enabled: true
              position: { top: 10, right: 12, bottom: 10, left: 12 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: data
                rows:
                  - ["SECTOR 01 · MAIN DOORS"]
                  - ["{{ 'OPEN' if is_state('input_boolean.lcards_test_doors', 'on') else 'SECURED' }}"]
                grid:
                  grid-template-columns: 1fr
                  grid-template-rows: repeat(2, min-content)
                  gap: 6px
                style:
                  font_size: 20px
                columns:
                  - style:
                      align: right
                      color: theme:colors.ui.secondary
          - type: custom:lcards-elbow
            elbow:
              type: frame
              segment: { color: theme:colors.card.topColor }
              frame: { bar_width: 4, bar_height: 4, outer_curve: 10 }
            background_animation:
              inset: auto
              effects: [{ preset: grid }]
            symbiont:
              enabled: true
              position: { top: 10, right: 12, bottom: 10, left: 12 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: data
                rows:
                  - ["SECTOR 02 · EXTERIOR"]
                  - ["{{ 'LIT' if is_state('input_boolean.lcards_test_lights', 'on') else 'DARK' }}"]
                grid:
                  grid-template-columns: 1fr
                  grid-template-rows: repeat(2, min-content)
                  gap: 6px
                style:
                  font_size: 20px
                columns:
                  - style:
                      align: right
                      color: theme:colors.ui.secondary
          - type: custom:lcards-elbow
            elbow:
              type: frame
              segment: { color: theme:colors.ui.tertiary }
              frame: { bar_width: 4, bar_height: 4, outer_curve: 10 }
            background_animation:
              inset: auto
              effects: [{ preset: grid }, { preset: scanlines }]
            symbiont:
              enabled: true
              position: { top: 10, right: 12, bottom: 10, left: 12 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: data
                rows:
                  - ["SECTOR 03 · PERIMETER"]
                  - ["{{ 'INTRUDER' if is_state('input_boolean.lcards_test_toggle', 'on') else 'CLEAR' }}"]
                grid:
                  grid-template-columns: 1fr
                  grid-template-rows: repeat(2, min-content)
                  gap: 6px
                style:
                  font_size: 20px
                columns:
                  - style:
                      align: right
                      color: theme:colors.ui.secondary
          - type: custom:lcards-elbow
            elbow:
              type: frame
              segment: { color: theme:colors.card.topColor }
              frame: { bar_width: 4, bar_height: 4, outer_curve: 10 }
            background_animation:
              inset: auto
              effects: [{ preset: grid }]
            symbiont:
              enabled: true
              position: { top: 10, right: 12, bottom: 10, left: 12 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: data
                rows:
                  - ["SECTOR 04 · CAMERA"]
                  - ["{{ 'PAN ' ~ (states('input_number.lcards_test_value') | int) ~ ' DEG' }}"]
                grid:
                  grid-template-columns: 1fr
                  grid-template-rows: repeat(2, min-content)
                  gap: 6px
                style:
                  font_size: 20px
                columns:
                  - style:
                      align: right
                      color: theme:colors.ui.secondary
        view_layout:
          grid-area: deco
      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          segment:
            bar_width: 170
            bar_height: 22
        view_layout:
          grid-area: footer
```
:::

## Alert mode

Buttons that raise and clear an [alert mode](../core/alert-mode) through the `lcards.*` [actions](../configuration/ha-actions), beside an everyday systems screen. The [alert overlay](../cards/alert-overlay/) covers the view with the symbol for the active alert: red, then yellow.

<video class="doc-video" src="/gallery/alert.webm" poster="/gallery/alert.webp" title="Alert dashboard: alert buttons beside a systems table, a data cascade and a chart; red alert covers it with the red overlay, then yellow alert with the yellow one" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Alert mode: buttons that raise and clear LCARdS alert modes (the lcards.* actions
# recolour every LCARdS dashboard) beside an everyday systems screen, and the alert
# overlay that covers the view while an alert is active.
title: Alert Mode
views:
  - title: Alert
    path: alert
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 170px minmax(0, 1fr) minmax(0, 1fr)
      grid-template-rows: 64px 70px 70px 70px 70px minmax(0, 1fr) 64px
      grid-template-areas: |
        "header header header"
        "red    status status"
        "yellow status status"
        "blue   status status"
        "clear  status status"
        "filler grid   chart"
        "footer footer footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          segment:
            bar_width: 170
            bar_height: 22
        text:
          title:
            content: ALERT STATUS
            position: bottom-right
            font_size: 24
            color: var(--lcards-orange)
        view_layout:
          grid-area: header
      # Shown over the view while an alert is active (no size: 60% x 50% of the screen).
      - type: custom:lcards-alert-overlay
        view_layout:
          grid-area: status
      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SYSTEM, STATUS, LEVEL]
            header: true
          - [MAIN POWER, "{{ 'ONLINE' if states('input_number.lcards_test_power') | int > 20 else 'LOW' }}", "{{ states('input_number.lcards_test_power') | int }} %"]
          - [SHIELDS, "{{ 'RAISED' if states('input_number.lcards_test_shields') | int > 0 else 'DOWN' }}", "{{ states('input_number.lcards_test_shields') | int }} %"]
          - [DOORS, "{{ 'OPEN' if is_state('input_boolean.lcards_test_doors', 'on') else 'SECURED' }}", ""]
          - [MODE, input_select.lcards_test_mode, ""]
        grid:
          grid-template-columns: 2fr 1fr 1fr
          grid-template-rows: repeat(5, min-content)
          gap: 6px
        style:
          font_size: 22px
        columns:
          - style:
              align: left
              color: var(--lcars-orange)
          - style:
              align: right
          - style:
              align: right
        view_layout:
          grid-area: status
      - type: custom:lcards-data-grid
        data_mode: decorative
        format: digit
        refresh_interval: 1500
        refresh_cells: 0.2
        grid:
          grid-template-rows: repeat(6, auto)
          grid-template-columns: repeat(6, 1fr)
          gap: 0px
        style:
          font_size: 20px
          color: var(--lcars-blue)
        view_layout:
          grid-area: grid
      - type: custom:lcards-chart
        chart_type: line
        graph_span: 12h
        sources:
          - entity: sensor.desk_sensor_temperature
            name: Deck 4
        view_layout:
          grid-area: chart
      - type: custom:lcards-button
        preset: filled
        style:
          card:
            color:
              background:
                default: var(--lcars-alert-red, #cc0000)
        text:
          name:
            content: RED ALERT
        tap_action:
          action: perform-action
          service: lcards.red_alert
        view_layout:
          grid-area: red
      - type: custom:lcards-button
        preset: filled
        style:
          card:
            color:
              background:
                default: var(--lcars-alert-yellow, #ffcc00)
        text:
          name:
            content: YELLOW ALERT
        tap_action:
          action: perform-action
          service: lcards.yellow_alert
        view_layout:
          grid-area: yellow
      - type: custom:lcards-button
        preset: filled
        style:
          card:
            color:
              background:
                default: var(--lcars-alert-blue, #3366ff)
        text:
          name:
            content: BLUE ALERT
        tap_action:
          action: perform-action
          service: lcards.blue_alert
        view_layout:
          grid-area: blue
      - type: custom:lcards-button
        preset: filled
        text:
          name:
            content: STAND DOWN
        tap_action:
          action: perform-action
          service: lcards.clear_alert
        view_layout:
          grid-area: clear
      - type: custom:lcards-button
        preset: panel-dark
        view_layout:
          grid-area: filler
      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          segment:
            bar_width: 170
            bar_height: 22
        view_layout:
          grid-area: footer
```
:::

## Picard era

Later LCARS screens (as on the USS Titan) use thinner, double-ringed frames, square-ended buttons, cooler blues and greys, and dense readouts with small orange accents. These two use the same cards in that style.

### Operations

Segmented double elbows, filled buttons that light up with their state, a [select menu](../cards/select-menu/) in the outline style, a cascade of changing hex values, a status table and two Picard sliders.

<video class="doc-video" src="/gallery/titan-operations.webm" poster="/gallery/titan-operations.webp" title="Operations dashboard: grey double elbows with orange accents framing light and door buttons, a mode selector, a blue cascade of hex numbers, a status table, two vertical Picard sliders and a temperature history" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Titan Operations: the Picard-era look (segmented double elbows, square-ended
# filled and outline buttons, Picard sliders, blue data cascades with orange accents).
# Uses lcards_test_* helpers and a temperature sensor; swap in your own entities.
title: Titan Operations
views:
  - title: Operations
    path: operations
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 210px minmax(0, 1fr) minmax(0, 1fr) 130px 130px
      grid-template-rows: 80px 52px 52px 52px 52px 140px minmax(0, 1fr) 80px
      grid-template-areas: |
        "header  header  header  header  header"
        "b1      cascade cascade power   shields"
        "b2      cascade cascade power   shields"
        "menu    cascade cascade power   shields"
        "menu    status  status  power   shields"
        "menu    status  status  power   shields"
        "chart   chart   chart   chart   chart"
        "footer  footer  footer  footer  footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-left
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 210
              bar_height: 24
              color: var(--lcards-gray-medium)
            inner_segment:
              bar_width: 48
              bar_height: 8
              color: var(--lcards-orange-medium)
        text:
          title:
            content: OPERATIONS · DECK 4
            position: bottom-right
            font_size: 26
            color: var(--lcards-blue-light)
        view_layout:
          grid-area: header
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_lights
        style:
          card:
            color:
              background:
                active: var(--lcards-orange)
                inactive: var(--lcards-gray-medium-dark)
        text:
          name:
            content: LIGHTS
        tap_action:
          action: toggle
        view_layout:
          grid-area: b1
      - type: custom:lcards-button
        preset: filled
        entity: input_boolean.lcards_test_doors
        style:
          card:
            color:
              background:
                active: var(--lcards-orange)
                inactive: var(--lcards-gray-medium-dark)
        text:
          name:
            content: DOORS
        tap_action:
          action: toggle
        view_layout:
          grid-area: b2
      - type: custom:lcards-data-grid
        data_mode: decorative
        format: hex
        refresh_interval: 1500
        refresh_cells: 0.15
        grid:
          grid-template-rows: repeat(4, auto)
          grid-template-columns: repeat(8, 1fr)
          gap: 0px
        columns:
          - format: digit
          - format: digit
        style:
          font_size: 22px
          color: var(--lcards-blue-light)
        highlight_changes:
          preset: pulse
          duration: 400
        view_layout:
          grid-area: cascade
      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SYSTEM, STATUS, LEVEL]
            header: true
          - [MAIN POWER, "{{ 'ONLINE' if states('input_number.lcards_test_power') | int > 20 else 'LOW' }}", "{{ states('input_number.lcards_test_power') | int }} %"]
          - [SHIELDS, "{{ 'RAISED' if states('input_number.lcards_test_shields') | int > 0 else 'DOWN' }}", "{{ states('input_number.lcards_test_shields') | int }} %"]
          - [MODE, input_select.lcards_test_mode, ""]
        grid:
          grid-template-columns: 2fr 1fr 1fr
          grid-template-rows: repeat(4, min-content)
          gap: 4px
        style:
          font_size: 18px
          color: var(--lcards-blue-light)
        columns:
          - style:
              align: left
              color: var(--lcards-orange)
          - style:
              align: right
          - style:
              align: right
        view_layout:
          grid-area: status
      - type: custom:lcards-slider
        entity: input_number.lcards_test_power
        preset: picard-gauge-vertical
        component: picard
        view_layout:
          grid-area: power
      - type: custom:lcards-slider
        entity: input_number.lcards_test_shields
        preset: picard-gauge-vertical
        component: picard
        view_layout:
          grid-area: shields
      - type: custom:lcards-select-menu
        entity: input_select.lcards_test_mode
        preset: outline
        grid:
          columns: 1
          gap: 6px
        view_layout:
          grid-area: menu
      - type: custom:lcards-chart
        chart_type: area
        graph_span: 24h
        sources:
          - entity: sensor.desk_sensor_temperature
            name: Deck 4
        style:
          colors:
            series:
              - var(--lcards-blue-light)
          fill:
            type: gradient
            gradient:
              opacityFrom: 0.45
              opacityTo: 0.02
        view_layout:
          grid-area: chart
      - type: custom:lcards-elbow
        elbow:
          type: footer-left
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 210
              bar_height: 24
              color: var(--lcards-gray-medium)
            inner_segment:
              bar_width: 48
              bar_height: 8
              color: var(--lcards-orange-medium)
        view_layout:
          grid-area: footer
```
:::

### Sciences

Segmented [frames](../cards/elbow/#frame-type) around a history chart with a smoothed [data source](../core/datasources/) trend and a set of radial gauges, a sensor table and hourly averages.

<video class="doc-video" src="/gallery/sciences.webm" poster="/gallery/sciences.webp" title="Sciences dashboard: a framed temperature history with a smoothed trend line, framed radial gauges for power, shields and humidity, a sensor table and a column chart of hourly averages" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Sciences: Picard-era readouts. Segmented frames around a history chart and a set of
# radial gauges, a sensor table and hourly averages, in cool blues and greys with
# orange accents. Uses lcards_test_* helpers and a temperature sensor.
title: Sciences
views:
  - title: Sciences
    path: sciences
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 8px
      grid-template-columns: minmax(0, 1.6fr) minmax(0, 1fr)
      grid-template-rows: 80px minmax(0, 1.3fr) minmax(0, 1fr) 70px
      grid-template-areas: |
        "header  header"
        "history gauges"
        "table   bars"
        "footer  footer"
    cards:
      - type: custom:lcards-elbow
        elbow:
          type: header-right
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 160
              bar_height: 24
              color: var(--lcards-blue-medium-light)
            inner_segment:
              bar_width: 40
              bar_height: 8
              color: var(--lcards-orange-medium)
        text:
          title:
            content: SCIENCES · SENSOR ANALYSIS
            position: bottom-left
            font_size: 26
            color: var(--lcards-blue-lightest)
        view_layout:
          grid-area: header

      # History: a segmented frame with the chart inside it.
      - type: custom:lcards-elbow
        elbow:
          type: frame
          style: segmented
          segment:
            color: var(--lcards-gray-medium)
          frame:
            bar_width: 14
            bar_height: 10
            segments:
              gap: 5
              inner_frame:
                bar_width: 4
                color: var(--lcards-blue-medium-light)
        view_layout:
          grid-area: history
      - type: custom:lcards-chart
        chart_type: area
        graph_span: 24h
        data_sources:
          deck_temp:
            entity: sensor.desk_sensor_temperature
            history:
              hours: 24
            processing:
              smoothed:
                type: smooth
                method: exponential
                alpha: 0.15
        sources:
          - datasource: deck_temp
            name: Deck 4
          - datasource: deck_temp
            buffer: smoothed
            name: Trend
        style:
          colors:
            series:
              - var(--lcards-blue-light)
              - var(--lcards-orange-medium)
          fill:
            type: gradient
            gradient:
              opacityFrom: 0.4
              opacityTo: 0.02
          legend:
            show: true
        view_layout:
          grid-area: history
          margin: 30px 34px

      # Gauges: radial bars for the live levels, in a matching frame.
      - type: custom:lcards-elbow
        elbow:
          type: frame
          style: segmented
          segment:
            color: var(--lcards-gray-medium)
          frame:
            bar_width: 14
            bar_height: 10
            segments:
              gap: 5
              inner_frame:
                bar_width: 4
                color: var(--lcards-orange-medium)
        view_layout:
          grid-area: gauges
      - type: custom:lcards-chart
        chart_type: radialBar
        sources:
          - entity: input_number.lcards_test_power
            name: Power
          - entity: input_number.lcards_test_shields
            name: Shields
          - entity: input_number.lcards_test_humidity
            name: Humidity
        style:
          colors:
            series:
              - var(--lcards-orange-medium)
              - var(--lcards-blue-light)
              - var(--lcards-blue-medium-light)
          legend:
            show: true
          chart_options:
            plotOptions:
              radialBar:
                startAngle: -135
                endAngle: 135
                hollow:
                  size: 35%
        view_layout:
          grid-area: gauges
          margin: 30px 34px

      - type: custom:lcards-data-grid
        data_mode: data
        rows:
          - values: [SENSOR, READING, STATUS]
            header: true
          - [DECK 4 TEMP, sensor.desk_sensor_temperature, NOMINAL]
          - [CABIN TEMP, input_number.lcards_test_temperature, NOMINAL]
          - [HUMIDITY, input_number.lcards_test_humidity, "{{ 'HIGH' if states('input_number.lcards_test_humidity') | int > 60 else 'NOMINAL' }}"]
          - [POWER, input_number.lcards_test_power, "{{ 'ONLINE' if states('input_number.lcards_test_power') | int > 20 else 'LOW' }}"]
        grid:
          grid-template-columns: 2fr 1fr 1fr
          grid-template-rows: repeat(5, min-content)
          gap: 6px
        style:
          font_size: 20px
          color: var(--lcards-blue-lightest)
        columns:
          - style:
              align: left
              color: var(--lcards-orange-medium)
          - style:
              align: right
          - style:
              align: right
              color: var(--lcards-blue-light)
        view_layout:
          grid-area: table

      - type: custom:lcards-chart
        chart_type: column
        graph_span: 12h
        sources:
          - entity: sensor.desk_sensor_temperature
            name: Hourly average
            group_by:
              func: avg
              duration: 1h
        style:
          colors:
            series:
              - var(--lcards-blue-medium-light)
        view_layout:
          grid-area: bars

      - type: custom:lcards-elbow
        elbow:
          type: footer-right
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 160
              bar_height: 24
              color: var(--lcards-blue-medium-light)
            inner_segment:
              bar_width: 40
              bar_height: 8
              color: var(--lcards-orange-medium)
        view_layout:
          grid-area: footer
```
:::

## Built from the design guide

Seven screens composed from the [archetypes](lcars-design#screen-archetypes) and [patterns](lcars-design#patterns) in Designing LCARS Screens, four Picard and three classic. Each starts from a different archetype, so together they show how varied the same design language can be. Every colour is a theme role: they follow your HA-LCARS theme, and the classic ones set a classic theme on their view.

### Picard: display with side columns

A Titan.DS-style console: small dark utility pills housed in a bracket frame with red alert at the bottom, a [concentric](lcars-design#concentric-sweep) header sweep whose leg matches the [code-block](lcars-design#code-block-column) column, vertical gauges, a nested frame around a dimmed ship schematic, a right number column with a cascade, [toggle tabs](lcars-design#toggle-tab-strip) and gauges along the bottom.

<video class="doc-video" src="/gallery/picard-console.webm" poster="/gallery/picard-console.webp" title="Picard console: grey sweeps and columns of code blocks, red accents on the blocks and tabs that are on, a dimmed blue ship in a nested frame, vertical and horizontal gauges and a column of numbers" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Picard console: a Titan.DS-style screen built from the patterns in
# doc/getting-started/lcars-design.md. Utility pills housed in a bracket frame, a concentric header
# sweep whose leg matches the column of code blocks, a nested frame around a line-drawn ship,
# a right number column, toggle tabs and gauges along the bottom, a footer sweep.
# Every colour is a theme role (theme: tokens), so it follows the HA-LCARS theme.
# Uses lcards_test_* helpers.
title: Picard Console
views:
  - title: Console
    path: console
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 130px 220px minmax(0, 1fr) 140px
      grid-template-rows: 90px minmax(0, 1fr) 56px 48px 48px
      grid-template-areas: |
        "pills top    top     top"
        "pills nums   main    rnums"
        "pills nums   tabs    rnums"
        "pills nums   gauges  rnums"
        "pills bottom bottom  bottom"
    cards:
      # Utility pills housed in a bracket frame (open on the left), red alert at the bottom.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: pills
        elbow:
          type: frame
          segment:
            color: theme:colors.ui.secondary
          frame:
            bar_width: 14
            bar_height: 36
            outer_curve: 36
            left:
              enabled: false
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: pills
        layout:
          padding: 46px 22px 46px 4px
          grid-gap: 8px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: 26px 26px 26px minmax(0, 1fr) 26px
        cards:
          - { type: custom:lcards-button, preset: lozenge, min_height: 26, text: { label: { content: ZOOM, show: true, position: center, color: theme:colors.ui.secondary } }, style: { card: { color: { background: { default: theme:colors.card.topColor } } } } }
          - { type: custom:lcards-button, preset: lozenge, min_height: 26, text: { label: { content: ABOUT, show: true, position: center, color: theme:colors.ui.secondary } }, style: { card: { color: { background: { default: theme:colors.card.topColor } } } } }
          - { type: custom:lcards-button, preset: lozenge, min_height: 26, text: { label: { content: DIMMER, show: true, position: center, color: theme:colors.ui.secondary } }, style: { card: { color: { background: { default: theme:colors.card.topColor } } } } }
          - { type: custom:lcards-button, preset: text-only, min_height: 0 }
          - type: custom:lcards-button
            preset: lozenge
            min_height: 26
            text: { label: { content: RED ALERT, show: true, position: center } }
            style:
              card:
                color:
                  background:
                    default: var(--lcars-alert-color, var(--lcards-orange-dark))
            tap_action:
              action: perform-action
              perform_action: lcards.red_alert

      # Header: a concentric sweep (thick outer, thin inner line); its leg is as wide as the code column.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: top
        elbow:
          type: header-left
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 220
              bar_height: 22
              color: theme:colors.ui.secondary
            inner_segment:
              bar_width: 6
              bar_height: 4
              color: theme:colors.ui.primary
        text:
          title:
            content: U.S.S. TITAN · SYSTEMS
            position: bottom-right
            font_size: 30
            color: theme:colors.ui.tertiary

      # Left number column: mostly structure; the three with helpers light up when on.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: nums
        layout:
          grid-gap: 6px
          grid-template-columns: repeat(2, minmax(0, 1fr))
          grid-template-rows: repeat(7, 32px) minmax(0, 1fr)
        cards:
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 63-934, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 13-650, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 19-638, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 42-991, position: center-right } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 28
            entity: input_boolean.lcards_test_lights
            text: { label: { content: 28-130, position: center-right } }
            tap_action: { action: toggle }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 50-957, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 81-782, position: center-right } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 28
            entity: input_boolean.lcards_test_doors
            text: { label: { content: 46-991, position: center-right } }
            tap_action: { action: toggle }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 95-132, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 85-334, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 92-548, position: center-right } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 28
            entity: input_boolean.lcards_test_toggle
            text: { label: { content: 97-747, position: center-right } }
            tap_action: { action: toggle }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 76-324, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 12-229, position: center-right } } }
          # Vertical gauges under the blocks, as on the Titan.DS consoles.
          - type: custom:lcards-slider
            component: picard
            preset: picard-gauge-vertical
            entity: input_number.lcards_test_power
          - type: custom:lcards-slider
            component: picard
            preset: picard-gauge-vertical
            entity: input_number.lcards_test_shields

      # Main display: a nested frame around the line-drawn ship.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: main
        elbow:
          type: frame
          style: segmented
          segment:
            color: theme:colors.ui.primary
          frame:
            bar_width: 12
            right:
              enabled: false
            segments:
              gap: 6
              inner_frame:
                bar_width: 4
                color: theme:colors.card.topColor
      - type: custom:lcards-msd-card
        view_layout:
          grid-area: main
        msd:
          base_svg:
            source: builtin:ncc-1701-a-blue
            # Dimmed: the schematic is data, not structure.
            filters:
              - { mode: css, type: opacity, value: 0.45 }
          view_box: [180, 270, 1600, 720]

      # Right number column.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: rnums
        layout:
          grid-gap: 6px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: repeat(10, 32px) minmax(0, 1fr)
        cards:
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 82-947, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: NCC-80102, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 57-835, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 83-370, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 23-714, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 87-718, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 78-485, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 97-923, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 85-199, position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 28, text: { label: { content: 74-700, position: center-right } } }
          # Numbers as texture in the space left over.
          - type: custom:lcards-data-grid
            data_mode: decorative
            format: digit
            grid:
              grid-template-rows: repeat(10, auto)
              grid-template-columns: repeat(3, minmax(0, 1fr))
              gap: 0px
            style:
              padding: 0px
              font_size: 16px
            animations:
              - trigger: on_load
                preset: cascade-color

      # Toggle tabs: state shows as a line along the top.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: tabs
        layout:
          grid-gap: 6px
          grid-template-columns: repeat(4, minmax(0, 1fr))
          grid-template-rows: minmax(0, 1fr)
        cards:
          - type: custom:lcards-button
            preset: toggle-tab
            entity: input_boolean.lcards_test_lights
            text: { name: { content: LIGHTS } }
            tap_action: { action: toggle }
          - type: custom:lcards-button
            preset: toggle-tab
            entity: input_boolean.lcards_test_doors
            text: { name: { content: DOORS } }
            tap_action: { action: toggle }
          - type: custom:lcards-button
            preset: toggle-tab
            entity: input_boolean.lcards_test_toggle
            text: { name: { content: SHIELDS } }
            tap_action: { action: toggle }
          - type: custom:lcards-button
            preset: toggle-tab
            text: { name: { content: AUDIO } }

      # Gauges along the bottom.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: gauges
        layout:
          grid-gap: 6px
          grid-template-columns: repeat(2, minmax(0, 1fr))
          grid-template-rows: minmax(0, 1fr)
        cards:
          - type: custom:lcards-slider
            entity: input_number.lcards_test_power
            preset: gauge-basic
          - type: custom:lcards-slider
            entity: input_number.lcards_test_shields
            preset: gauge-basic

      # Footer sweep closes the frame.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: bottom
        elbow:
          type: footer-left
          segment:
            bar_width: 220
            bar_height: 16
            color: theme:colors.ui.secondary
        text:
          subtitle:
            content: STARSHIP DB · W-255
            position: top-right
            font_size: 18
            color: theme:colors.ui.quaternary
```
:::

### Picard: display over controls

A concentric header sweep continued by a [segmented bar](lcars-design#segmented-bar-classic-arms) of codes, a wide nested frame around a grey shuttle schematic, and a control deck under it: a [gauge bank](lcars-design#gauge-bank), a [tile wall](lcars-design#tile-wall), [readout rows](lcars-design#readout-rows) and a [selector strip](lcars-design#selector-strip).

<video class="doc-video" src="/gallery/picard-display.webm" poster="/gallery/picard-display.webp" title="Picard display: facing grey sweeps with a red title, a wide frame around a grey shuttlecraft schematic, four vertical gauges, four framed number tiles, three readout gauges and a mode selector" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Picard display: the "display over controls" archetype from doc/getting-started/lcars-design.md.
# Facing sweeps across the top, a wide nested frame around a dimmed ship schematic, and a
# control deck under it: a gauge bank, a wall of framed tiles, readout rows and a selector
# strip. Every colour is a theme role. Uses lcards_test_* helpers.
title: Picard Display
views:
  - title: Display
    path: display
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 8px
      grid-template-columns: minmax(0, 1fr) minmax(0, 1.4fr) minmax(0, 1.2fr)
      grid-template-rows: 80px minmax(0, 1.25fr) minmax(0, 1fr) 48px
      grid-template-areas: |
        "headl   headl   headr"
        "display display display"
        "gauges  tiles   readout"
        "gauges  tiles   sel"
    cards:
      # Header: a concentric sweep with the title, continued by a segmented bar of codes.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: headl
        elbow:
          type: header-left
          style: segmented
          segments:
            gap: 6
            outer_segment:
              bar_width: 150
              bar_height: 20
              color: theme:colors.ui.secondary
            inner_segment:
              bar_width: 5
              bar_height: 4
              color: theme:colors.ui.primary
        text:
          title:
            content: DECK PLAN · SECTION 7
            position: bottom-right
            font_size: 28
            color: theme:colors.ui.tertiary
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: headr
        layout:
          grid-gap: 6px
          grid-template-columns: 2fr 1fr 3fr 1fr
          grid-template-rows: 20px
        cards:
          - { type: custom:lcards-button, preset: panel-dark, min_height: 20, text: { label: { content: "47-2201", position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 20, text: { label: { content: "08", position: center-right } } }
          - { type: custom:lcards-button, preset: panel-dark, min_height: 20, text: { label: { content: "NAVIGATIONAL REFERENCE", position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 20, text: { label: { content: "541", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }

      # The display: a nested frame around the ship, dimmed so it reads as data.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: display
        elbow:
          type: frame
          style: segmented
          segment:
            color: theme:colors.card.topColor
          frame:
            bar_width: 8
            segments:
              gap: 6
              inner_frame:
                bar_width: 3
                color: theme:colors.ui.primary
      - type: custom:lcards-msd-card
        view_layout:
          grid-area: display
        msd:
          base_svg:
            source: builtin:enterprise-d-shuttlecraft15-anomaly
            # Grey and dimmed: on a Picard screen the schematic is data, not structure.
            filters:
              - { mode: css, type: grayscale, value: 1 }
              - { mode: css, type: opacity, value: 0.55 }
          view_box: [-40, -50, 1123, 560]

      # Gauge bank.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: gauges
        layout:
          grid-gap: 8px
          grid-template-columns: repeat(4, minmax(0, 1fr))
          grid-template-rows: minmax(0, 1fr)
        cards:
          - { type: custom:lcards-slider, component: picard, preset: picard-gauge-vertical, entity: input_number.lcards_test_power }
          - { type: custom:lcards-slider, component: picard, preset: picard-gauge-vertical, entity: input_number.lcards_test_shields }
          - { type: custom:lcards-slider, component: picard, preset: picard-gauge-vertical, entity: input_number.lcards_test_temperature }
          - { type: custom:lcards-slider, component: picard, preset: picard-gauge-vertical, entity: input_number.lcards_test_humidity }

      # Tile wall: framed readings, each embedded in its frame.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: tiles
        layout:
          grid-gap: 10px
          grid-template-columns: repeat(2, minmax(0, 1fr))
          grid-template-rows: repeat(2, minmax(0, 1fr))
        cards:
          - type: custom:lcards-elbow
            elbow:
              type: frame
              segment: { color: theme:colors.card.topColor }
              frame: { bar_width: 4, bar_height: 4, outer_curve: 10 }
            symbiont:
              enabled: true
              position: { top: 10, right: 10, bottom: 10, left: 10 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: decorative
                format: digit
                grid:
                  grid-template-rows: repeat(3, auto)
                  grid-template-columns: repeat(3, minmax(0, 1fr))
          - type: custom:lcards-elbow
            elbow:
              type: frame
              segment: { color: theme:colors.card.topColor }
              frame: { bar_width: 4, bar_height: 4, outer_curve: 10 }
            symbiont:
              enabled: true
              position: { top: 10, right: 10, bottom: 10, left: 10 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: decorative
                format: hex
                grid:
                  grid-template-rows: repeat(3, auto)
                  grid-template-columns: repeat(3, minmax(0, 1fr))
          - type: custom:lcards-elbow
            entity: input_boolean.lcards_test_doors
            elbow:
              type: frame
              segment:
                color:
                  default: theme:colors.card.topColor
                  active: theme:colors.ui.tertiary
                  inactive: theme:colors.card.topColor
              frame: { bar_width: 4, bar_height: 4, outer_curve: 10 }
            symbiont:
              enabled: true
              position: { top: 10, right: 10, bottom: 10, left: 10 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: decorative
                format: float
                grid:
                  grid-template-rows: repeat(3, auto)
                  grid-template-columns: repeat(3, minmax(0, 1fr))
          - type: custom:lcards-elbow
            elbow:
              type: frame
              segment: { color: theme:colors.card.topColor }
              frame: { bar_width: 4, bar_height: 4, outer_curve: 10 }
            symbiont:
              enabled: true
              position: { top: 10, right: 10, bottom: 10, left: 10 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: decorative
                format: alpha
                grid:
                  grid-template-rows: repeat(3, auto)
                  grid-template-columns: repeat(3, minmax(0, 1fr))

      # Readout rows.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: readout
        layout:
          grid-gap: 6px
          grid-template-columns: 110px minmax(0, 1fr)
          grid-template-rows: repeat(3, minmax(0, 1fr))
        cards:
          - { type: custom:lcards-button, preset: panel-dark, min_height: 0, text: { label: { content: POWER, position: center-right } } }
          - { type: custom:lcards-slider, preset: gauge-basic, entity: input_number.lcards_test_power }
          - { type: custom:lcards-button, preset: panel-dark, min_height: 0, text: { label: { content: SHIELDS, position: center-right } } }
          - { type: custom:lcards-slider, preset: gauge-basic, entity: input_number.lcards_test_shields }
          - { type: custom:lcards-button, preset: panel-dark, min_height: 0, text: { label: { content: HUMIDITY, position: center-right } } }
          - { type: custom:lcards-slider, preset: gauge-basic, entity: input_number.lcards_test_humidity }

      # Selector strip.
      - type: custom:lcards-select-menu
        view_layout:
          grid-area: sel
        entity: input_select.lcards_test_mode
        preset: toggle-tab
        grid:
          columns: 3
          gap: 6px
```
:::

### Picard: split screen

A split header in the Picard style: two [segmented elbows](lcars-design#concentric-sweep) (a thin outer band with a large curve around a wide inner block) face each other across a cut through the screen, each band running on as thin segments. Utility pills sit inside the upper curve and [flagged blocks](lcars-design#flagged-blocks) inside the lower one, around readout gauges, a cascade, a radar scope and a framed ship schematic.

<video class="doc-video" src="/gallery/picard-split.webm" poster="/gallery/picard-split.webp" title="Picard split screen: two grey segmented sweeps facing across a cut through the screen, pills in the upper curve, flagged code blocks in the lower, readout gauges, a number cascade, a radar scope, a dimmed blue ship and toggle tabs" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Picard split: a split header in the Picard style, from doc/getting-started/lcars-design.md.
# Two segmented elbows (a thin outer band with a large curve around a wide inner block, as
# in the lcars-shell strategy) face each other across a cut through the screen; each band
# runs on as thin segments. Utility pills sit inside the upper curve, flagged code blocks
# inside the lower one. Every colour is a theme role. Uses lcards_test_* helpers.
title: Picard Split
views:
  - title: Split
    path: split
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 8px
      grid-template-columns: 210px 130px minmax(0, 1fr) 280px
      grid-template-rows: 300px minmax(0, 1fr)
      grid-template-areas: |
        "ucorner ucorner upper upper"
        "lcorner lcorner lower lower"
    cards:
      # Upper half: a segmented elbow sweeping down into the cut.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: ucorner
        elbow:
          type: footer-left
          style: segmented
          segments:
            gap: 5
            outer_segment:
              bar_width: 40
              bar_height: 14
              outer_curve: 120
              inner_curve: 70
              color: theme:colors.ui.primary
            inner_segment:
              bar_width: 150
              bar_height: 30
              inner_curve: 30
              color: theme:colors.ui.quaternary
      # Utility pills inside the upper curve.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: ucorner
        layout:
          padding: 16px 12px 70px 210px
          grid-gap: 8px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: 26px 26px 26px minmax(0, 1fr) 26px
        cards:
          - { type: custom:lcards-button, preset: lozenge, min_height: 26, text: { label: { content: ZOOM, show: true, position: center, color: theme:colors.ui.secondary } }, style: { card: { color: { background: { default: theme:colors.card.topColor } } } } }
          - { type: custom:lcards-button, preset: lozenge, min_height: 26, text: { label: { content: ABOUT, show: true, position: center, color: theme:colors.ui.secondary } }, style: { card: { color: { background: { default: theme:colors.card.topColor } } } } }
          - { type: custom:lcards-button, preset: lozenge, min_height: 26, text: { label: { content: DIMMER, show: true, position: center, color: theme:colors.ui.secondary } }, style: { card: { color: { background: { default: theme:colors.card.topColor } } } } }
          - { type: custom:lcards-button, preset: text-only, min_height: 0 }
          - type: custom:lcards-button
            preset: lozenge
            min_height: 26
            text: { label: { content: RED ALERT, show: true, position: center } }
            style: { card: { color: { background: { default: "var(--lcars-alert-color, var(--lcards-orange-dark))" } } } }
            tap_action: { action: perform-action, perform_action: lcards.red_alert }

      # Upper content, closed at the bottom by the band running on as thin segments.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: upper
        layout:
          grid-gap: 8px
          grid-template-columns: minmax(0, 1fr) minmax(0, 1fr) 280px
          grid-template-rows: 48px minmax(0, 1fr) 14px
          grid-template-areas: |
            "dots   title  title"
            "rows   cascade gauges"
            "s1     s2     s3"
        cards:
          - type: custom:lcards-button
            view_layout: { grid-area: dots }
            preset: text-only
            min_height: 0
            text: { label: { content: "•  •••  ••  •••••  •  ••", show: true, position: center-left, color: theme:colors.ui.secondary } }
          - type: custom:lcards-button
            view_layout: { grid-area: title }
            preset: text-only
            min_height: 0
            text: { label: { content: "U.S.S. TITAN · OPERATIONS", show: true, position: center-right, font_size: 32, color: theme:colors.ui.tertiary } }
          - type: custom:lcards-layout-card
            view_layout: { grid-area: rows }
            layout:
              grid-gap: 6px
              grid-template-columns: 110px minmax(0, 1fr)
              grid-template-rows: repeat(3, minmax(0, 1fr))
            cards:
              - { type: custom:lcards-button, preset: panel-dark, min_height: 0, text: { label: { content: POWER, position: center-right } } }
              - { type: custom:lcards-slider, preset: gauge-basic, entity: input_number.lcards_test_power }
              - { type: custom:lcards-button, preset: panel-dark, min_height: 0, text: { label: { content: SHIELDS, position: center-right } } }
              - { type: custom:lcards-slider, preset: gauge-basic, entity: input_number.lcards_test_shields }
              - { type: custom:lcards-button, preset: panel-dark, min_height: 0, text: { label: { content: HUMIDITY, position: center-right } } }
              - { type: custom:lcards-slider, preset: gauge-basic, entity: input_number.lcards_test_humidity }
          - type: custom:lcards-data-grid
            view_layout: { grid-area: cascade }
            data_mode: decorative
            format: digit
            grid:
              grid-template-rows: repeat(6, auto)
              grid-template-columns: repeat(4, minmax(0, 1fr))
              gap: 0px
            style:
              padding: 0px
              font_size: 18px
            animations:
              - trigger: on_load
                preset: cascade-color
          - type: custom:lcards-button
            view_layout: { grid-area: gauges }
            component: radar
          - { type: custom:lcards-button, preset: panel-light, min_height: 14, view_layout: { grid-area: s1 }, text: { label: { content: "", show: false } } }
          - { type: custom:lcards-button, preset: panel-dark, min_height: 14, view_layout: { grid-area: s2 }, text: { label: { content: "", show: false } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 14, view_layout: { grid-area: s3 }, text: { label: { content: "", show: false } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }

      # Lower half: the mirror elbow sweeping up out of the cut.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: lcorner
        elbow:
          type: header-left
          style: segmented
          segments:
            gap: 5
            outer_segment:
              bar_width: 40
              bar_height: 14
              outer_curve: 120
              inner_curve: 70
              color: theme:colors.ui.primary
            inner_segment:
              bar_width: 150
              bar_height: 30
              inner_curve: 30
              color: theme:colors.ui.quaternary
      # Flagged code blocks inside the lower curve; two follow helpers.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: lcorner
        layout:
          padding: 70px 12px 16px 210px
          grid-gap: 6px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: repeat(8, 30px)
        cards:
          - { type: custom:lcards-button, preset: panel-flagged, min_height: 30, text: { label: { content: "012" } } }
          - { type: custom:lcards-button, preset: panel-flagged, min_height: 30, entity: input_boolean.lcards_test_lights, tap_action: { action: toggle }, text: { label: { content: "330" } } }
          - { type: custom:lcards-button, preset: panel-flagged, min_height: 30, text: { label: { content: "436" } } }
          - { type: custom:lcards-button, preset: panel-flagged, min_height: 30, entity: input_boolean.lcards_test_doors, tap_action: { action: toggle }, text: { label: { content: "23" } } }
          - { type: custom:lcards-button, preset: panel-flagged, min_height: 30, text: { label: { content: "542" } } }
          - { type: custom:lcards-button, preset: panel-flagged, min_height: 30, text: { label: { content: "7439" } } }
          - { type: custom:lcards-button, preset: panel-flagged, min_height: 30, text: { label: { content: "4057" } } }
          - { type: custom:lcards-button, preset: panel-flagged, min_height: 30, text: { label: { content: "0007" } } }

      # Lower content: the band runs on as thin segments along the top, then a framed
      # display and a column of blocks and tabs.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: lower
        layout:
          grid-gap: 8px
          grid-template-columns: minmax(0, 1fr) 280px
          grid-template-rows: 14px minmax(0, 1fr)
          grid-template-areas: |
            "segs segs"
            "display side"
        cards:
          - type: custom:lcards-layout-card
            view_layout: { grid-area: segs }
            layout:
              grid-gap: 6px
              grid-template-columns: 3fr 1fr 5fr 2fr
              grid-template-rows: 14px
            cards:
              - { type: custom:lcards-button, preset: panel-dark, min_height: 14, text: { label: { content: "", show: false } } }
              - { type: custom:lcards-button, preset: panel-light, min_height: 14, text: { label: { content: "", show: false } } }
              - { type: custom:lcards-button, preset: panel-dark, min_height: 14, text: { label: { content: "", show: false } } }
              - { type: custom:lcards-button, preset: panel-light, min_height: 14, text: { label: { content: "", show: false } } }
          - type: custom:lcards-elbow
            view_layout: { grid-area: display }
            elbow:
              type: frame
              segment: { color: theme:colors.card.topColor }
              frame: { bar_width: 3, bar_height: 3, outer_curve: 24 }
          - type: custom:lcards-msd-card
            view_layout: { grid-area: display }
            msd:
              base_svg:
                source: builtin:ncc-1701-a-blue
                filters:
                  - { mode: css, type: opacity, value: 0.45 }
              view_box: [180, 270, 1600, 720]
          - type: custom:lcards-layout-card
            view_layout: { grid-area: side }
            layout:
              grid-gap: 6px
              grid-template-columns: minmax(0, 1fr)
              grid-template-rows: repeat(6, 30px) minmax(0, 1fr) 48px 48px
            cards:
              - { type: custom:lcards-button, preset: panel-light, min_height: 30, text: { label: { content: 58-347, position: center-right } } }
              - { type: custom:lcards-button, preset: panel-dark, min_height: 30, text: { label: { content: NCC-80102, position: center-right } } }
              - { type: custom:lcards-button, preset: panel-light, min_height: 30, text: { label: { content: 45-721, position: center-right } } }
              - { type: custom:lcards-button, preset: panel-light, min_height: 30, text: { label: { content: 10-732, position: center-right } } }
              - { type: custom:lcards-button, preset: panel-dark, min_height: 30, text: { label: { content: 52-741, position: center-right } } }
              - { type: custom:lcards-button, preset: panel-light, min_height: 30, text: { label: { content: 25-225, position: center-right } } }
              - { type: custom:lcards-button, preset: text-only, min_height: 0 }
              - type: custom:lcards-button
                preset: toggle-tab
                entity: input_boolean.lcards_test_lights
                text: { name: { content: LIGHTS } }
                tap_action: { action: toggle }
              - type: custom:lcards-button
                preset: toggle-tab
                entity: input_boolean.lcards_test_doors
                text: { name: { content: DOORS } }
                tap_action: { action: toggle }
```
:::

### Picard: portrait panel

For a phone or an upright tablet: a [header bar](lcars-design#header-bar-with-a-title) with the title, code blocks beside a condition readout, a tile wall, a gauge bank, toggle tabs and a segmented closing bar. Recorded at 600 by 1000.

<video class="doc-video" src="/gallery/picard-portrait.webm" poster="/gallery/picard-portrait.webp" title="Picard portrait: a red MISSION OPS header bar, code blocks beside a condition readout, three framed number tiles, three vertical gauges and three toggle tabs" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Picard portrait: the "portrait panel" archetype from doc/getting-started/lcars-design.md,
# for a phone or an upright wall tablet. A header bar with the title, a condition readout
# beside a column of code blocks, a tile wall, a gauge bank, toggle tabs and a segmented
# closing bar. Every colour is a theme role. Uses lcards_test_* helpers.
title: Picard Portrait
views:
  - title: Portrait
    path: portrait
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 10px
      grid-gap: 8px
      grid-template-columns: 120px minmax(0, 1fr)
      grid-template-rows: 56px 150px 120px minmax(0, 1fr) 52px 40px
      grid-template-areas: |
        "title  title"
        "codes  status"
        "tiles  tiles"
        "gauges gauges"
        "tabs   tabs"
        "foot   foot"
    cards:
      # Header bar with the title.
      - type: custom:lcards-button
        view_layout:
          grid-area: title
        preset: bar-label-left
        text:
          label:
            content: MISSION OPS
            color: theme:colors.ui.tertiary
        style:
          card:
            color:
              background:
                default: theme:colors.ui.tertiary

      # Code blocks, two of them tied to helpers.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: codes
        layout:
          grid-gap: 6px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: repeat(4, minmax(0, 1fr))
        cards:
          - { type: custom:lcards-button, preset: panel-light, min_height: 0, text: { label: { content: 07-82, position: center-right } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            entity: input_boolean.lcards_test_lights
            text: { label: { content: 75-15, position: center-right } }
            tap_action: { action: toggle }
          - { type: custom:lcards-button, preset: panel-dark, min_height: 0, text: { label: { content: 7-385, position: center-right } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            entity: input_boolean.lcards_test_doors
            text: { label: { content: 19-587, position: center-right } }
            tap_action: { action: toggle }

      # Condition readout.
      - type: custom:lcards-data-grid
        view_layout:
          grid-area: status
        data_mode: data
        rows:
          - values: [CONDITION, "{{ 'NORMAL' if states('input_number.lcards_test_shields') | int > 30 else 'ALERT' }}"]
          - [POWER, "{{ states('input_number.lcards_test_power') | int }} %"]
          - [SHIELDS, "{{ states('input_number.lcards_test_shields') | int }} %"]
        grid:
          grid-template-columns: 1fr 1fr
          grid-template-rows: repeat(3, min-content)
          gap: 6px
        style:
          font_size: 20px
        columns:
          - style:
              align: left
              color: theme:colors.ui.primary
          - style:
              align: right
              color: theme:colors.ui.tertiary

      # Tile wall.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: tiles
        layout:
          grid-gap: 8px
          grid-template-columns: repeat(3, minmax(0, 1fr))
          grid-template-rows: minmax(0, 1fr)
        cards:
          - type: custom:lcards-elbow
            elbow:
              type: frame
              segment: { color: theme:colors.card.topColor }
              frame: { bar_width: 3, bar_height: 3, outer_curve: 8 }
            symbiont:
              enabled: true
              position: { top: 8, right: 8, bottom: 8, left: 8 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: decorative
                format: digit
                grid:
                  grid-template-rows: repeat(3, auto)
                  grid-template-columns: repeat(2, minmax(0, 1fr))
          - type: custom:lcards-elbow
            elbow:
              type: frame
              segment: { color: theme:colors.ui.tertiary }
              frame: { bar_width: 3, bar_height: 3, outer_curve: 8 }
            symbiont:
              enabled: true
              position: { top: 8, right: 8, bottom: 8, left: 8 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: decorative
                format: hex
                grid:
                  grid-template-rows: repeat(3, auto)
                  grid-template-columns: repeat(2, minmax(0, 1fr))
          - type: custom:lcards-elbow
            elbow:
              type: frame
              segment: { color: theme:colors.card.topColor }
              frame: { bar_width: 3, bar_height: 3, outer_curve: 8 }
            symbiont:
              enabled: true
              position: { top: 8, right: 8, bottom: 8, left: 8 }
              imprint: { enabled: false }
              card:
                type: custom:lcards-data-grid
                data_mode: decorative
                format: float
                grid:
                  grid-template-rows: repeat(3, auto)
                  grid-template-columns: repeat(2, minmax(0, 1fr))

      # Gauge bank.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: gauges
        layout:
          grid-gap: 8px
          grid-template-columns: repeat(3, minmax(0, 1fr))
          grid-template-rows: minmax(0, 1fr)
        cards:
          - { type: custom:lcards-slider, component: picard, preset: picard-gauge-vertical, entity: input_number.lcards_test_power }
          - { type: custom:lcards-slider, component: picard, preset: picard-gauge-vertical, entity: input_number.lcards_test_shields }
          - { type: custom:lcards-slider, component: picard, preset: picard-gauge-vertical, entity: input_number.lcards_test_humidity }

      # Toggle tabs.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: tabs
        layout:
          grid-gap: 6px
          grid-template-columns: repeat(3, minmax(0, 1fr))
          grid-template-rows: minmax(0, 1fr)
        cards:
          - type: custom:lcards-button
            preset: toggle-tab
            entity: input_boolean.lcards_test_lights
            text: { name: { content: LIGHTS } }
            tap_action: { action: toggle }
          - type: custom:lcards-button
            preset: toggle-tab
            entity: input_boolean.lcards_test_doors
            text: { name: { content: DOORS } }
            tap_action: { action: toggle }
          - type: custom:lcards-button
            preset: toggle-tab
            entity: input_boolean.lcards_test_toggle
            text: { name: { content: AUX } }
            tap_action: { action: toggle }

      # A segmented bar closes the panel (no sweep: nothing below for it to turn into).
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: foot
        layout:
          grid-gap: 6px
          grid-template-columns: 120px 3fr 1fr 2fr
          grid-template-rows: 16px
        cards:
          - { type: custom:lcards-button, preset: panel-light, min_height: 16, text: { label: { content: "", show: false } } }
          - { type: custom:lcards-button, preset: panel-dark, min_height: 16, text: { label: { content: "453899-23780", position: center-right } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 16, text: { label: { content: "692", position: center-right } } }
          - { type: custom:lcards-button, preset: panel-dark, min_height: 16, text: { label: { content: "4301-795-418", position: center-right } } }
```
:::

### Classic: sweep console

The classic look: thick header and footer sweeps continued as [labelled segments](lcars-design#segmented-bar-classic-arms), a sidebar of coloured blocks with code numbers, a [pill grid](lcars-design#pill-grid-classic) led by big numbers, a slider over a strip of small pills, and a number cascade. The view sets `theme: LCARS Default`, so the roles come out in the TNG pastels whatever your profile theme is.

<video class="doc-video" src="/gallery/tng-console.webm" poster="/gallery/tng-console.webp" title="TNG console: peach header sweep and blocks, rows of pastel pills led by large numbers, two control bars, a pill slider and a column of blue numbers" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# TNG console: the classic look from the patterns in doc/getting-started/lcars-design.md.
# Thick colour blocks as structure: header and footer sweeps continued as labelled
# segments, a sidebar of blocks with code numbers, a pill grid led by big numbers in
# alternating roles, a slider and a strip of small pills, a number cascade. Every colour
# is a theme role, and the view uses the LCARS Default theme, so the roles come out in
# the classic pastels. Uses lcards_test_* helpers.
title: TNG Console
views:
  - title: Operations
    path: operations
    theme: LCARS Default
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 6px
      grid-template-columns: 170px 110px minmax(0, 3fr) minmax(0, 2fr)
      grid-template-rows: 56px 64px minmax(0, 1fr) 150px 70px
      grid-template-areas: |
        "corner corner bar    bar"
        "corner corner title  title"
        "side   pills  pills  readout"
        "side   status status readout"
        "fcorner fcorner fbar fbar"
    cards:
      # Header: a short thick sweep, the bar continued as labelled segments in several roles.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: corner
        elbow:
          type: header-left
          segment:
            bar_width: 170
            bar_height: 56
            color: theme:colors.ui.primary
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: bar
        layout:
          grid-gap: 6px
          grid-template-columns: 3fr 1fr 4fr 2fr 2fr
          grid-template-rows: 56px
        cards:
          - { type: custom:lcards-button, preset: panel-light, min_height: 56, text: { label: { content: "COURSE SELECT", position: bottom-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 56, text: { label: { content: "541", position: bottom-right } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 56, text: { label: { content: "NAVIGATIONAL REFERENCE", position: bottom-right } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 56, text: { label: { content: "FLIGHT CONTROL", position: bottom-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 56, text: { label: { content: "47-2201", position: bottom-right } }, style: { card: { color: { background: { default: theme:colors.card.topColor } } } } }
      - type: custom:lcards-button
        view_layout:
          grid-area: title
        preset: text-only
        min_height: 0
        text:
          label:
            content: OPERATIONS • 40272
            show: true
            position: center-right
            font_size: 34
            color: theme:colors.ui.tertiary

      # Sidebar of blocks with code numbers, in different roles.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: side
        layout:
          grid-gap: 6px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: 2fr 1fr 1fr 3fr 1fr
        cards:
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            text: { label: { content: 01-23564 } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            text: { label: { content: 02-24156 } }
            style: { card: { color: { background: { default: theme:colors.ui.secondary } } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            text: { label: { content: 03-41248 } }
            style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            text: { label: { content: 04-14702 } }
            style: { card: { color: { background: { default: theme:colors.card.topColor } } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            text: { label: { content: 05-32456 } }

      # Pill grid: each row led by a big number, groups in alternating roles.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: pills
        layout:
          grid-gap: 8px
          grid-template-columns: 90px repeat(3, minmax(0, 1fr))
          grid-template-rows: repeat(5, minmax(0, 1fr))
        cards:
          - { type: custom:lcards-button, preset: text-only, min_height: 0, text: { label: { content: "20", show: true, position: center-right, font_size: 40, color: theme:colors.ui.tertiary } } }
          - type: custom:lcards-button
            preset: lozenge
            entity: input_boolean.lcards_test_lights
            text: { label: { content: LIGHTS, show: true } }
            tap_action: { action: toggle }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: AF 1137, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: NK 0042, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: text-only, min_height: 0, text: { label: { content: "008", show: true, position: center-right, font_size: 40, color: theme:colors.ui.secondary } } }
          - type: custom:lcards-button
            preset: lozenge
            entity: input_boolean.lcards_test_doors
            text: { label: { content: DOORS, show: true } }
            tap_action: { action: toggle }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: LK 7351, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: GH 8812, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: text-only, min_height: 0, text: { label: { content: "72", show: true, position: center-right, font_size: 40, color: theme:colors.ui.primary } } }
          - type: custom:lcards-button
            preset: lozenge
            entity: input_boolean.lcards_test_toggle
            text: { label: { content: SHIELDS, show: true } }
            tap_action: { action: toggle }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: SE 9104, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: BE 3320, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: text-only, min_height: 0, text: { label: { content: "358", show: true, position: center-right, font_size: 40, color: theme:colors.ui.tertiary } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: LE 4471, show: true } }, style: { card: { color: { background: { default: theme:colors.card.topColor } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: FW 6620, show: true } }, style: { card: { color: { background: { default: theme:colors.card.topColor } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: VD 1998, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: text-only, min_height: 0, text: { label: { content: "451", show: true, position: center-right, font_size: 40, color: theme:colors.ui.secondary } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: HU 2045, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: MA 5531, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: AN 7764, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }

      # Readout: a number cascade.
      - type: custom:lcards-data-grid
        view_layout:
          grid-area: readout
        data_mode: decorative
        format: mixed
        grid:
          grid-template-rows: repeat(10, auto)
          grid-template-columns: repeat(5, minmax(0, 1fr))
          gap: 0px
        style:
          padding: 0px
          font_size: 20px
        animations:
          - trigger: on_load
            preset: cascade-color

      # Under the pills: the power slider, then a strip of small pills (TNG panel strips).
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: status
        layout:
          grid-gap: 8px
          grid-template-columns: repeat(6, minmax(0, 1fr))
          grid-template-rows: minmax(0, 1fr) 40px
          grid-template-areas: |
            "slider slider slider slider slider slider"
            "p1 p2 p3 p4 p5 p6"
        cards:
          - type: custom:lcards-slider
            view_layout: { grid-area: slider }
            entity: input_number.lcards_test_power
            preset: pills-basic
          - { type: custom:lcards-button, preset: lozenge, min_height: 0, view_layout: { grid-area: p1 }, text: { label: { content: "GS IRC", show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: lozenge, min_height: 0, view_layout: { grid-area: p2 }, text: { label: { content: "KK TFD", show: true } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: lozenge, min_height: 0, view_layout: { grid-area: p3 }, text: { label: { content: "LA TWE", show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: lozenge, min_height: 0, view_layout: { grid-area: p4 }, text: { label: { content: "BR TAS", show: true } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }
          - { type: custom:lcards-button, preset: lozenge, min_height: 0, view_layout: { grid-area: p5 }, text: { label: { content: "IF WSD", show: true } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: lozenge, min_height: 0, view_layout: { grid-area: p6 }, text: { label: { content: "LO PRC", show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }

      # Footer: a short sweep, the bottom bar continued as segments.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: fcorner
        elbow:
          type: footer-left
          segment:
            bar_width: 170
            bar_height: 30
            color: theme:colors.ui.primary
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: fbar
        layout:
          grid-gap: 6px
          grid-template-columns: 2fr 5fr 1fr 2fr
          grid-template-rows: minmax(0, 1fr) 30px
          grid-template-areas: |
            ". . . sub"
            "s1 s2 s3 s4"
        cards:
          - type: custom:lcards-button
            view_layout: { grid-area: sub }
            preset: text-only
            min_height: 0
            text: { label: { content: LCARS 23295, show: true, position: center-right, font_size: 20, color: theme:colors.ui.secondary } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 30, view_layout: { grid-area: s1 }, text: { label: { content: "PRIMARY CONTROL", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 30, view_layout: { grid-area: s2 }, text: { label: { content: "AUXILIARY CONTROL", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 30, view_layout: { grid-area: s3 }, text: { label: { content: "08", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 30, view_layout: { grid-area: s4 }, text: { label: { content: "4301-795", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
```
:::
### Classic: bracket screen

DS9-style: top and bottom bars broken into labelled segments, a sidebar of coloured blocks with code numbers, a shuttlecraft cutaway in colour, a readout list and a row of pills. The view uses `theme: LCARS Zeldaar`.

<video class="doc-video" src="/gallery/ds9-bracket.webm" poster="/gallery/ds9-bracket.webp" title="DS9 bracket: violet top and bottom sweeps, a sidebar of violet, peach, rose and blue blocks, a colourful shuttlecraft cutaway, a system status list and a row of pills" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# DS9 bracket: the "bracket screen" archetype from doc/getting-started/lcars-design.md.
# A top and a bottom bar (short sweeps continued as labelled segments) with the title, a sidebar of blocks with code numbers, a
# cutaway display, a side readout list and a row of pills under the display. The view
# uses the LCARS Zeldaar theme for a DS9 palette; every colour is a theme role.
# Uses lcards_test_* helpers.
title: DS9 Bracket
views:
  - title: Runabout
    path: runabout
    theme: LCARS Zeldaar
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 8px
      grid-template-columns: 150px 110px minmax(0, 3fr) minmax(0, 1fr)
      grid-template-rows: 70px minmax(0, 1fr) 64px 70px
      grid-template-areas: |
        "tcorner tcorner tbar    tbar"
        "side    display display list"
        "side    pills   pills   list"
        "bcorner bcorner bbar    bbar"
    cards:
      # Top bar: a short sweep continued as segments, the title under them.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: tcorner
        elbow:
          type: header-left
          segment:
            bar_width: 150
            bar_height: 26
            color: theme:colors.ui.primary
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: tbar
        layout:
          grid-gap: 6px
          grid-template-columns: 4fr 1fr 2fr 1fr
          grid-template-rows: 26px minmax(0, 1fr)
          grid-template-areas: |
            "s1 s2 s3 s4"
            ". title title title"
        cards:
          - { type: custom:lcards-button, preset: panel-light, min_height: 26, view_layout: { grid-area: s1 }, text: { label: { content: "FEDERATION/CARDASSIAN BORDER", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 26, view_layout: { grid-area: s2 }, text: { label: { content: "78", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 26, view_layout: { grid-area: s3 }, text: { label: { content: "BAJOR SECTOR", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 26, view_layout: { grid-area: s4 }, text: { label: { content: "2369", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - type: custom:lcards-button
            view_layout: { grid-area: title }
            preset: text-only
            min_height: 0
            text: { label: { content: "SHUTTLECRAFT SYSTEMS • 3645", show: true, position: center-right, font_size: 30, color: theme:colors.ui.tertiary } }

      # Sidebar: blocks of different heights in different roles, each with a code.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: side
        layout:
          grid-gap: 8px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: 1fr 2fr 1fr 1fr 3fr
        cards:
          - { type: custom:lcards-button, preset: panel-light, min_height: 0, text: { label: { content: 848-5094 } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            text: { label: { content: 374-8463 } }
            style: { card: { color: { background: { default: theme:colors.ui.secondary } } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            entity: input_boolean.lcards_test_lights
            text: { label: { content: 348-4636 } }
            tap_action: { action: toggle }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            text: { label: { content: 754-9473 } }
            style: { card: { color: { background: { default: theme:colors.card.topColor } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 0, text: { label: { content: 758-5094 } } }

      # The display: the shuttle cutaway, in colour.
      - type: custom:lcards-msd-card
        view_layout:
          grid-area: display
        msd:
          base_svg:
            source: builtin:enterprise-d-shuttlecraft15-anomaly
          view_box: [-20, -20, 1083, 499]

      # Readout list beside the display.
      - type: custom:lcards-data-grid
        view_layout:
          grid-area: list
        data_mode: data
        rows:
          - values: [SYSTEM, STATUS]
            header: true
          - [IMPULSE, "{{ states('input_number.lcards_test_power') | int }} %"]
          - [SHIELDS, "{{ states('input_number.lcards_test_shields') | int }} %"]
          - [CABIN, "{{ states('input_number.lcards_test_temperature') }} C"]
          - [HUMIDITY, "{{ states('input_number.lcards_test_humidity') | int }} %"]
          - [LIGHTS, "{{ states('input_boolean.lcards_test_lights') | upper }}"]
          - [HATCH, "{{ 'OPEN' if is_state('input_boolean.lcards_test_doors', 'on') else 'SEALED' }}"]
        grid:
          grid-template-columns: 1fr 1fr
          grid-template-rows: repeat(7, min-content)
          gap: 8px
        style:
          font_size: 20px
        columns:
          - style:
              align: left
              color: theme:colors.ui.secondary
          - style:
              align: right
              color: theme:colors.ui.tertiary

      # Pills under the display, in two roles.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: pills
        layout:
          grid-gap: 8px
          grid-template-columns: repeat(5, minmax(0, 1fr))
          grid-template-rows: minmax(0, 1fr)
        cards:
          - type: custom:lcards-button
            preset: lozenge
            entity: input_boolean.lcards_test_doors
            text: { label: { content: HATCH, show: true } }
            tap_action: { action: toggle }
          - type: custom:lcards-button
            preset: lozenge
            entity: input_boolean.lcards_test_toggle
            text: { label: { content: SHIELDS, show: true } }
            tap_action: { action: toggle }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: 21-7745, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: 40-2274, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: 68-5009, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }

      # Bottom bar: the same, mirrored.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: bcorner
        elbow:
          type: footer-left
          segment:
            bar_width: 150
            bar_height: 26
            color: theme:colors.ui.primary
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: bbar
        layout:
          grid-gap: 6px
          grid-template-columns: 2fr 1fr 4fr 1fr
          grid-template-rows: minmax(0, 1fr) 26px
          grid-template-areas: |
            ". . . sub"
            "s1 s2 s3 s4"
        cards:
          - type: custom:lcards-button
            view_layout: { grid-area: sub }
            preset: text-only
            min_height: 0
            text: { label: { content: "73647-8947", show: true, position: center-right, font_size: 22, color: theme:colors.ui.secondary } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 26, view_layout: { grid-area: s1 }, text: { label: { content: "UNIT 15", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 26, view_layout: { grid-area: s2 }, text: { label: { content: "47", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 26, view_layout: { grid-area: s3 }, text: { label: { content: "BOUNDARIES PRIOR TO HOSTILITIES", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 26, view_layout: { grid-area: s4 }, text: { label: { content: "4747", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }
```
:::

### Classic: list

Voyager-style: a [split header](lcars-design#split-header-classic) whose two bars continue as segments, a number cascade, a duty roster [list](lcars-design#list), a column of big numbers and pill groups. The view uses `theme: LCARS Nemesis Blue`.

<video class="doc-video" src="/gallery/voyager-roster.webm" poster="/gallery/voyager-roster.webp" title="Voyager roster: a tan upper sweep and a blue lower sweep, a duty roster in four coloured columns, a column of large numbers, a number cascade and a row of pills" autoplay loop muted playsinline></video>

::: details YAML
```yaml
# Voyager roster: the "list" archetype from doc/getting-started/lcars-design.md. A split
# header (an upper block sweeping down into a bar, a lower one sweeping out of the next),
# a number cascade in the header, a roster list, a column of big numbers and a row of
# pill groups. The view uses the LCARS Nemesis Blue theme; every colour is a theme role.
# Uses lcards_test_* helpers.
title: Voyager Roster
views:
  - title: Roster
    path: roster
    theme: LCARS Nemesis Blue
    type: custom:lcards-layout-view
    layout:
      height: calc(100dvh - var(--header-height, 56px))
      padding: 12px
      grid-gap: 8px
      grid-template-columns: 160px 100px minmax(0, 1fr) 260px
      grid-template-rows: 150px 50px minmax(0, 1fr) 70px
      grid-template-areas: |
        "ucorner ucorner upper   cascade"
        "lcorner lcorner lower   lower"
        "side    list    list    numbers"
        "pills   pills   pills   pills"
    cards:
      # Split header: the upper block sweeps down into a bar continued as segments...
      - type: custom:lcards-elbow
        view_layout:
          grid-area: ucorner
        elbow:
          type: footer-left
          segment:
            bar_width: 160
            bar_height: 20
            color: theme:colors.ui.secondary
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: upper
        layout:
          grid-gap: 6px
          grid-template-columns: 3fr 1fr 2fr
          grid-template-rows: minmax(0, 1fr) 20px
          grid-template-areas: |
            "title title title"
            "s1 s2 s3"
        cards:
          - type: custom:lcards-button
            view_layout: { grid-area: title }
            preset: text-only
            min_height: 0
            text: { label: { content: "VOYAGER DUTY ROSTER · 12.25.95", show: true, position: center-right, font_size: 32, color: theme:colors.ui.tertiary } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 20, view_layout: { grid-area: s1 }, text: { label: { content: "CREW ASSIGNMENTS", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 20, view_layout: { grid-area: s2 }, text: { label: { content: "47", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 20, view_layout: { grid-area: s3 }, text: { label: { content: "DECK 5", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }

      - type: custom:lcards-data-grid
        view_layout:
          grid-area: cascade
        data_mode: decorative
        format: digit
        grid:
          grid-template-rows: repeat(5, auto)
          grid-template-columns: repeat(4, minmax(0, 1fr))
          gap: 0px
        style:
          padding: 0px
          font_size: 18px
        animations:
          - trigger: on_load
            preset: cascade-color
      # ...and the lower one sweeps out of the next, also continued as segments.
      - type: custom:lcards-elbow
        view_layout:
          grid-area: lcorner
        elbow:
          type: header-left
          segment:
            bar_width: 160
            bar_height: 20
            color: theme:colors.ui.primary
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: lower
        layout:
          grid-gap: 6px
          grid-template-columns: 1fr 4fr 1fr 2fr
          grid-template-rows: 20px
        cards:
          - { type: custom:lcards-button, preset: panel-light, min_height: 20, text: { label: { content: "02-262000", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 20, text: { label: { content: "OPTICAL DATA NETWORK AVAILABLE", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 20, text: { label: { content: "12", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } } }
          - { type: custom:lcards-button, preset: panel-light, min_height: 20, text: { label: { content: "03-111968", position: center-right } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }

      # Sidebar under the lower sweep.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: side
        layout:
          grid-gap: 8px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: 2fr 1fr 1fr
        cards:
          - { type: custom:lcards-button, preset: panel-light, min_height: 0, text: { label: { content: 03-111968 } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            text: { label: { content: 04-041969 } }
            style: { card: { color: { background: { default: theme:colors.ui.tertiary } } } }
          - type: custom:lcards-button
            preset: panel-light
            min_height: 0
            text: { label: { content: 05-1701D } }
            style: { card: { color: { background: { default: theme:colors.card.topColor } } } }

      # The roster.
      - type: custom:lcards-data-grid
        view_layout:
          grid-area: list
        data_mode: data
        rows:
          - values: [Name, Station, Shift, Status]
            header: true
          - [TUVOK, SECURITY, ALPHA, ON DUTY]
          - [TORRES, ENGINEERING, BETA, ON DUTY]
          - [PARIS, CONN, ALPHA, ON DUTY]
          - [KIM, OPERATIONS, GAMMA, OFF DUTY]
          - [NEELIX, GALLEY, ALPHA, ON DUTY]
          - [SEVEN, ASTROMETRICS, BETA, OFF DUTY]
          - [DOCTOR, SICKBAY, ALL, ACTIVE]
          - [CHAKOTAY, COMMAND, ALPHA, ON DUTY]
        grid:
          grid-template-columns: 1.2fr 1.4fr 0.8fr 1fr
          grid-template-rows: repeat(9, min-content)
          gap: 6px
        style:
          font_size: 20px
        columns:
          - style:
              align: left
              color: theme:colors.ui.tertiary
          - style:
              align: left
              color: theme:colors.ui.primary
          - style:
              align: left
              color: theme:colors.ui.secondary
          - style:
              align: right
              color: theme:colors.ui.primary

      # A column of big numbers.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: numbers
        layout:
          grid-gap: 4px
          grid-template-columns: minmax(0, 1fr)
          grid-template-rows: repeat(4, minmax(0, 1fr))
        cards:
          - { type: custom:lcards-button, preset: text-only, min_height: 0, text: { label: { content: "752", show: true, position: center-right, font_size: 54, color: theme:colors.ui.secondary } } }
          - { type: custom:lcards-button, preset: text-only, min_height: 0, text: { label: { content: "77", show: true, position: center-right, font_size: 54, color: theme:colors.ui.tertiary } } }
          - { type: custom:lcards-button, preset: text-only, min_height: 0, text: { label: { content: "04", show: true, position: center-right, font_size: 54, color: theme:colors.ui.primary } } }
          - { type: custom:lcards-button, preset: text-only, min_height: 0, text: { label: { content: "003", show: true, position: center-right, font_size: 54, color: theme:colors.ui.secondary } } }

      # Pill groups along the bottom.
      - type: custom:lcards-layout-card
        view_layout:
          grid-area: pills
        layout:
          grid-gap: 8px
          grid-template-columns: repeat(6, minmax(0, 1fr))
          grid-template-rows: minmax(0, 1fr)
        cards:
          - type: custom:lcards-button
            preset: lozenge
            entity: input_boolean.lcards_test_lights
            text: { label: { content: LIGHTS, show: true } }
            tap_action: { action: toggle }
          - type: custom:lcards-button
            preset: lozenge
            entity: input_boolean.lcards_test_doors
            text: { label: { content: DOORS, show: true } }
            tap_action: { action: toggle }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: 07 9012, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: 09 4421, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.primary } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: 12 6610, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
          - { type: custom:lcards-button, preset: lozenge, text: { label: { content: 15 0087, show: true } }, style: { card: { color: { background: { default: theme:colors.ui.secondary } } } } }
```
:::
