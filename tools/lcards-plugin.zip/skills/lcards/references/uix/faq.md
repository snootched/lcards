<!-- From the UIX documentation, https://uix.lf.technology/faq (commit e5832fa, 2026-11-20). Docs prose CC BY 4.0, examples MIT (c) Lint-Free Technology. Reformatted for plain markdown. -->

# FAQ

## How do I best migrate from Card-mod?

- Uninstall card-mod.
- If you use extra_module_url for card-mod resource, remove and restart Home Assistant.
- Proceed to follow the [UI eXtension quick start guide](./quick-start.md).

**UI eXtension is a Service:**

UI eXtension is an integration and needs to be added as a Service. If you install using Marketplace this step is done automatically. If anything seems to not be working, make sure UI eXtension has been added as a Service in [Devices and services](https://my.home-assistant.io/redirect/devices/?search=uix).

**UI Lovelace Minimalist may load card-mod resource:**

If you have UI Lovelace Minimalist installed it may load card-mod resource. Due to load order of integrations, UI eXtension cannot check for this conflict. To continue to use UI Lovelace Minimalist with UI eXtension you need to turn off UI Lovelace Minimalist config option `Include custom card resources it's depending on` and load any required custom cards through Marketplace or manually.

## Is UI eXtension a drop in replacement for Card-mod?

Yes, UI eXtension is a drop in replacement for Card-mod versions up to 4.2.1. All Card-mod card and themes configurations are supported. While you are encouraged to update to use `uix:` in your cards and `uix-<thing>(-yaml)` for your themes, it is not required.

## Is UI eXtension just Card-mod with different documentation?

No, UI eXtension code has been updated so that UIX is primary domain and config key. Card-mod keys are supported but overridden by `uix:`.

**UI eXtension differences from Card-mod:**

- Config key for cards is `uix:`.
- Theme key is `uix-theme:`.
- Theme `thing` keys are `uix-<thing>(-yaml):`.
- HTML node for UI eXtension is `<uix-node>` and properties of the node all refer to `uix`.
- You can use `{# uix.debug #}` to debug templates.
- All debug console messages will start with `UIX`.

## Is there a list of differences between Card-mod and UI eXtension?

Yes, see the table below.

<!-- markdownlint-disable MD033 -->
| Feature | Card-mod | UIX |
| --- | :---: | :---: |
| Correctly loads `...-yaml` theme variables | ❌<br>Since 2026.8.0 | Yes |
| Correctly handles `...-more-info(-yaml)` theme variable | ❌<br>Since 2026.3.0 | Yes |
| Correctly patches adaptive dialogs for `...-dialog(-yaml)` theme variable | ❌<br>Since 2026.3.0 | Yes |
| [DOM inspection helpers](https://uix.lf.technology/concepts/dom/#dom-inspection-helpers) | No | Yes |
| [Host/element path selection](https://uix.lf.technology/concepts/dom/#hostelement-path-selection) | No | Yes |
| [Express search selector](https://uix.lf.technology/concepts/dom/#express-search-selector) | No | Yes |
| [Forge](https://uix.lf.technology/forge/) (custom lovelace element) | No | Yes |
| [Forge - Foundries](https://uix.lf.technology/forge/foundries/) (reusable forges) | No | Yes |
| [Forge - Macros](https://uix.lf.technology/using/templates/#macros) (reusable jinja templates) | No | Yes |
| [Forge - Sparks](https://uix.lf.technology/forge/sparks/) (self-contained behaviours that augment forged elements) | No | Yes |
| [Broker](https://uix.lf.technology/broker/) (create declarative frontend event interactions) | No | Yes |
| [Frontend state throttling](https://uix.lf.technology/extras/frontend-states-throttling/) (optional) | No | Yes |
| [Dialog Styling delay](https://uix.lf.technology/extras/dialog-styling-delay/) (optional) | No | Yes |
| [Dashboard view backgrounds](https://uix.lf.technology/using/view-backgrounds/) | No | Yes |
| [Section backgrounds](https://uix.lf.technology/using/section-backgrounds/) | No | Yes |
| [View backgrounds](https://uix.lf.technology/using/view-backgrounds/) | No | Yes |
| [Icon styling - entity override](https://uix.lf.technology/using/icons/#specifying-for-an-entity-override) | No | Yes |
| [Styling entity images](https://uix.lf.technology/using/images/) | No | Yes |
| [Styling custom panels](https://uix.lf.technology/using/custom-panels/) (including those loaded as iFrames) | No | Yes |
| [Styling app and ingress panels](https://uix.lf.technology/using/apps/) (including those loaded as iFrames) | No | Yes |
| Reload/Clear cache popup | No | Yes |
| Expansive documentation including visual examples | Limited | Yes |
| Mod-Card | Yes | Yes |
| CSS styling in themes | Yes | Yes |
| Reload/Clear cache service/action | Yes | Yes |
| Provides variables (e.g current user) | Yes | Yes |
| CSS styling | Yes | Yes |
| Resource url | Yes | N/A |

## Does UI eXtension have resource URL issues?

No, being an integration, UI eXtension manages its resource URLs directly. You don't need to do anything to have UI eXtension run at peak performance. UI eXtension dynamically adds its Frontend resource, `uix.js`, as an extra module, as well as adding a Dashboard resource in case you use CAST. UI eXtension will add its version to these resources automatically each time the integration loads.

## Does UI eXtension need manual cache clear after upgrade for Browsers and device Companion Apps?

UI eXtension will show a toast message when it detects that a reload is needed to clear caches, with a convenient `Reload Now` button and auto reload after 60s.

**Note:**

While the Auto reload code is in 8.1.0, auto Reload will be available when you next update. When you install 8.1.0, device will still be running 8.0.1 code which does not have the auto reload feature.

## Can the reload toast message be suppressed?

No, the toast messages exist to satisfy the requirement of Frontend UIX JavaScript code matching the UIX integration code.

The toast is shown when UIX has been changed and Home Assistant has restarted, but the browser is still running a cached UIX bundle from a different version.

An auto reload happens after 60 seconds, allowing unattended kiosks to update their Frontend code.

**Tip:**

After updating UIX, restart Home Assistant when you are ready to activate the update. Until then, UIX continues serving the version that was loaded when Home Assistant started.

## How do I uninstall UI eXtension?

### Marketplace

Browse to [UIX](https://my.home-assistant.io/redirect/marketplace_repository/?owner=Lint-Free-Technology&repository=uix&category=integration) in Marketplace. Use the three dots menu and choose Uninstall. This will remove the UI eXtension service as well as remove UI eXtension files from Home Assistant.

**Important:**

Uninstalling via Marketplace will remove any Service configuration of UI eXtension including Foundries, custom Sidebar panels and other settings configured via the UI eXtension service. No dashboard or theme YAML is removed but will become non-functional.

### Manual

Uninstallation of UI eXtension is a two step process. First, remove the service entry in Devices & services. Next uninstall the integration by removing the `uix` folder from `custom_components` directory.
